/**
 * 
 */
function sub() {
	var custname= document.getElementById("custname").value;
	var sex= document.getElementById("sex").value;
	var mobile = document.getElementById("phone").value;
	var card = document.getElementById('card_no').value;
	var address= document.getElementById("address").value;
	var ismarry= document.getElementById("ismarry").value;
	var drive= document.getElementById("drive").value;
	var money= document.getElementById("money").value;
	var debt= document.getElementById("debt").value;
	var carprice= document.getElementById("carPrice").value;
	var size= document.getElementById("carBoxsize").value;
	var lsqmoney = document.getElementById("lsqmoney").value;
	var lsqtime = document.getElementById("lsqtime").value;
	if(checkname(custname)==false){
		document.getElementById("msg_name").innerHTML='*请输入姓名';
		return false;
	}else if(checkname(custname)==true){
		document.getElementById("msg_name").innerHTML='√ yes';
	}
	if(checkmobile(mobile)==false){
		return false;	
	}else if(checkmobile(mobile)==true){
		document.getElementById("msg_phone").innerHTML='√ yes';
	}
	if(checkCard(card)==false){
		return false;
	}else if(checkCard(card)==true){
		document.getElementById("msg_card").innerHTML='√ yes';
	}
	if(carprice.length == 0){
		document.getElementById("msg_price").innerHTML='*请输入';
		return false;
	}else if(checkfloatnum(carprice)==false){
		document.getElementById("msg_price").innerHTML='*格式不正确';
		return false;
	}else{
		document.getElementById("msg_price").innerHTML='√ yes';
	}
	if(size.length == 0){
		document.getElementById("msg_size").innerHTML='*请输入';
		return false;
	}else if(checkfloatnum(size)==false){
		document.getElementById("msg_size").innerHTML='*格式不正确';
		return false;
	}else{
		document.getElementById("msg_size").innerHTML='√ yes';
	}
	
	if(lsqmoney.length == 0){
		document.getElementById("msg_sqmoney").innerHTML='*请输入';
		return false;
	}else if(checkfloatnum(lsqmoney)==false){
		document.getElementById("msg_sqmoney").innerHTML='*格式不正确';
		return false;
	}else{
		document.getElementById("msg_sqmoney").innerHTML='√ yes';
	}
	if(lsqtime.length == 0){
		document.getElementById("msg_sqtime").innerHTML='*请输入';
		return false;
	}else if(checkintnum(lsqtime)==false){
		document.getElementById("msg_sqtime").innerHTML='*格式不正确';
		return false;
	}else{
		document.getElementById("msg_sqtime").innerHTML='√ yes';
	}
	/*alert('你输入的信息是：'+
			'姓名:'+custname+
			',性别:'+sex+
			',电话:'+mobile+
			',身份证号:'+card+
			',地址:'+address+
			',婚姻状况:'+ismarry+
			',驾照:'+drive+
			',资产:'+money+
			',负债情况:'+debt);*/
	return true;
} function checkname(custname){
	var len = custname.length;
	if(len==0){
		 document.getElementById("custname").focus();
		return false;
	}return true;
}
   function checkmobile(mobile) {
	   var len = mobile.length;
	   if(len==0)
		{
		   document.getElementById("msg_phone").innerHTML='*请输入手机号';
		   document.getElementById("phone").focus();
		   return false;
		}    
		if(len!=11)
		{
			document.getElementById("msg_phone").innerHTML='*太长或太短！';
		    document.getElementById("phone").focus();
		    return false;
		}if(isphone(mobile)==false){
			document.getElementById("msg_phone").innerHTML='*请输入有效的手机号码！';
		    document.getElementById("phone").focus();
		    return false;
		}
		    return true;
     }
    isphone = function(mobile){
    	var regmobile = /^1[3|5|7|8|][0-9]{9}/;
    	if(regmobile.test(mobile)){
    		return true;
    	}
    	else{
    		return false;
    	}
    };
    var vcity={ 11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",
            21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏",
            33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",
            42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",
            51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",
            63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"
           };	
     checkCard = function(card)
    	{
    	    //是否为空
    	    if(card === '')
    	    {
    	    	document.getElementById("msg_card").innerHTML='*请输入身份证号，身份证号不能为空！';
    	        document.getElementById('card_no').focus();
    	        return false;
    	    }
    	    //校验长度，类型
    	    if(isCardNo(card) === false)
    	    {
    	    	document.getElementById("msg_card").innerHTML='*您输入不够18位或大于18位！';
    	        document.getElementById('card_no').focus();
    	        return false;
    	    }
    	    //检查省份
    	    if(checkProvince(card) === false)
    	    {
    	        document.getElementById("msg_card").innerHTML='*没有该地区的身份证,请重新输入！';
    	        document.getElementById('card_no').focus();
    	        return false;
    	    }
    	    //校验生日
    	    if(checkBirthday(card) === false)
    	    {
    	        document.getElementById("msg_card").innerHTML='*您输入的身份证号码生日不正确,请重新输入！';
    	        document.getElementById('card_no').focus();
    	        return false;
    	    }
    	    //检验位的检测
    	    if(checkParity(card) === false)
    	    {
    	        document.getElementById("msg_card").innerHTML='*您的身份证校验位不正确,请重新输入！';
    	        document.getElementById('card_no').focus();
    	        return false;
    	    }
    	    return true;
    	};

    	//检查号码是否符合规范，包括长度，类型
    	isCardNo = function(card)
    	{
    	    var reg = /^\d{17}(\d|X)$/;
    	    if(reg.test(card) === false)
    	    {
    	        return false;
    	    }
    	    return true;
    	}; 
    	//取身份证前两位,校验省份
    	checkProvince = function(card)
    	{
    	    var province = card.substr(0,2);
    	    if(vcity[province] == undefined)
    	    {
    	        return false;
    	    }
    	    return true;
    	};
	    //检查生日是否正确
    	checkBirthday = function(card)
    	{
    	    var len = card.length;
    	    //身份证18位时，次序为省（3位）市（3位）年（4位）月（2位）日（2位）校验位（4位），校验位末尾可能为X
    	    if(len == '18')
    	    {
    	        var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
    	        var arr_data = card.match(re_eighteen);
    	        var year = arr_data[2];
    	        var month = arr_data[3];
    	        var day = arr_data[4];
    	        var birthday = new Date(year+'/'+month+'/'+day);
    	        return verifyBirthday(year,month,day,birthday);
    	    }else{
    	    	return false;
    	    }
    	};
    	//校验日期
    	verifyBirthday = function(year,month,day,birthday)
    	{
    	    var now = new Date();
    	    var now_year = now.getFullYear();
    	    //年月日是否合理
    	    if(birthday.getFullYear() == year && (birthday.getMonth() + 1) == month && birthday.getDate() == day)
    	    {
    	        //判断年份的范围（3岁到100岁之间)
    	        var time = now_year - year;
    	        if(time >= 18 && time <= 100)
    	        {
    	            return true;
    	        }
    	        else{
    	        	alert('年龄太小或太大!请重新输入!');
    	            return false;
    	          }
    	    }
    	    return false;
    	};
        //校验位的检测
    	checkParity = function(card)
    	{
    	    var len = card.length;
    	    if(len == '18')
    	    {
    	        var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
    	        var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
    	        var cardTemp = 0, i, valnum;
    	        for(i = 0; i < 17; i ++)
    	        {
    	            cardTemp += card.substr(i, 1) * arrInt[i];
    	        }
    	        valnum = arrCh[cardTemp % 11];
    	        if (valnum == card.substr(17, 1))
    	        {
    	            return true;
    	        }
    	        return false;
    	    }
    	    return false;
    	};
    	//校验正浮点数
    	checkfloatnum = function(num){
    		var regnum = /^(([0-9]+\\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\\.[0-9]+)|([0-9]*[1-9][0-9]*))$/;
    	    if(regnum.test(num)==false){
    	    	
    	    	return false;
    	    }return true;
    	};
    	//校验正整数
    	checkintnum = function(num){
    		var regnum = /^[0-9]*[1-9][0-9]*$/;
    		if(regnum.test(num)==false){
    	    	return false;
    	    }return true;
    	}