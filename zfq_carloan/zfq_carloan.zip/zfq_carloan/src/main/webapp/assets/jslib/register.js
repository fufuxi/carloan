/**
 * 
 */
      var xmlHttp = false; //全局变量，用于记录XMLHttpRequest对象
       function createXMLHttpRequest() {
         if(window.ActiveXObject) { //Internet Explorer时，创建XMLHttpRequest对象的方法
           try {
             xmlHttp = new ActiveXObject("Msxml2.XMLHTTP");
           } catch(e) {
             try {
               xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
                //旧版本的Internet Explorer，创建XMLHttpRequest对象
             } catch(e) {
               window.alert("创建XMLHttpRequest对象错误"+e);
             } 
           }
         } else if(window.XMLHttpRequest) { //mozilla时，创建XMLHttpRequest对象的方法
           xmlHttp = new XMLHttpRequest();
         } 
         if(!(xmlHttp)) { //未成功创建XMLHttpRequest对象
             window.alert("创建XMLHttpRequest对象异常！");
         }  
       }
       function cityChange(objVal) {
    	        createXMLHttpRequest(); //创建XMLHttpRequest对象
    	        document.getElementById("village").length = 1;     //根据ID获取指定元素，并赋值
    	        xmlHttp.onreadystatechange = cityList; //指定onreadystatechange处理函数
    	        var url = "/village/list?cityId=" + objVal; //请求的URL地址
    	        xmlHttp.open("GET",url,true);
    	        xmlHttp.send(null);
    	       }
              function cityList() { //onreadystatechange的处理函数
    	           if(xmlHttp.readyState==4) {
    	              if(xmlHttp.status==200) {
    	                parseXML(xmlHttp.responseText);     //解析服务器返回的字符串数据
    	              }
    	            }
    	          }
    	         function parseXML(msg) {
    	        	 var data=$.parseJSON(msg);
   				      for(var i = 0 ;i<data.length;i++){
   				      $("#village").append(function(index,html){
   					    var option = "<option value = \""+data[i].vid+"\">" +data[i].vname+ "</option>";
   					     return option;
   					  });
   				   }
    	          }
    	         function v(){
    	        	 var city = document.getElementById("city").value;
    	        	 var village = document.getElementById("village").value;
    	        	 document.getElementById("address").value = city + "-" + village;
    	         }
   $(document).ready(function() {
	//查询所有车	
	   $.ajax({
			type:"POST",
			url:"/car/list",
			success:function(msg){	
				var data=$.parseJSON(msg);
				  for(var i = 0 ;i<data.length;i++){
				      $("#carBrand").append(function(index,html){
					    var option = "<option value = \""+data[i].carBrand+"\">" +data[i].carBrand+ "</option>";
					    return option;
					  });
				   }
				}	 
		 });
	$.ajax({
		type:"POST",
		url:"/city/list",
		success:function(msg){	
			var data=$.parseJSON(msg);
			  for(var i = 0 ;i<data.length;i++){
			      $("#city").append(function(index,html){
				    var option = "<option value = \""+data[i].cityId+"\">" +data[i].cityName+ "</option>";
				    return option;
				  });
			   }
			}	 
	   });
		$.ajax({
			type:"POST",
			url:"/bank/list",
			success:function(msg){	
				var data=$.parseJSON(msg);
				  for(var i = 0 ;i<data.length;i++){
				      $("#bankselect").append(function(index,html){
					    var option = "<option value = \""+data[i].bankId+"\">" +data[i].bankSimpleName+ "</option>";
					    return option;
					  });
				   }
				}	 
		   });
	  });
   