
            // 图片张数
            var length;
            // currentIndex当前图片索引，默认是0
            var currentIndex = 0;
            // 用于保存播放的定时器
            var interval;
            // hasStarted表示是否开始播放，一开始是false
            var hasStarted = false;
            // 
            var t = 3000;
            
            // length = 4
            length = $('.slider-panel').length;
            // 不是第1个的隐藏
            $('.slider-panel:not(:first)').hide();
            // 
            $('.slider-item:first').addClass('slider-item-selected');
            
            // 鼠标的悬停事件
            // 参数1 鼠标放上来的时执行
            // 参数2 鼠标移走之后执行
            $('.slider-panel').hover(function(){
                stop();
            }, function(){
                start();
            });
            
            // play()播放实现轮播
            // 从preIndex翻页到currentIndex
            // preIndex翻页的起始页
            // currentIndex要翻到的那一页
            function play(preIndex, currentIndex){
                // fadeOut()淡出函数，参数是时间500ms
                $('.slider-panel').eq(preIndex).fadeOut(500).parent().children().eq(currentIndex).fadeIn(1000);
                // 移除将要淡出的图片对应的指示器的样式
                $('.slider-item').removeClass('slider-item-selected');
                $('.slider-item').eq(currentIndex).addClass('slider-item-selected');
            }
            
            // 向后翻页的函数
            // 在这里调用play(),给它传入参数
            function next(){
                var preIndex = currentIndex;
                currentIndex = ++currentIndex % length;
                // 调用play()函数传入参数
                // 参数是两个相邻的数字并且是循环出现的
                play(preIndex, currentIndex);
            }
            
            // start()函数表示开始播放
            function start(){
                if(!hasStarted){
                    // 播放时把标志hasStarted改为true
                    hasStarted = true;
                    interval = setInterval(next ,t);
                }
            }
            start();
            // 停止播放
            function stop(){
                clearInterval(interval);
                hasStarted = false;
            }
            
