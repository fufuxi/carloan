/**
 * 
 */
package cn.edu.nuc.carloan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysrole;
import cn.edu.nuc.carloan.services.interfaces.SysroleService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午2:23:51 
 *@ version:1.0
 *@ 类说明 :角色管理控制层
 */
@Controller
public class SysroleController {
    @Autowired
    SysroleService sysroleService;
    @RequestMapping(value="/role/list")
    private String rolelist(HttpServletRequest request, @RequestParam(name = "current", defaultValue = "1") int current,
			Model model) {
		String rolename = request.getParameter("rolename");
		Sysrole role = new Sysrole();
		if (rolename != null && !rolename.equals("")) {
			role.setRolename(rolename);
		}
		PageInfo pi = sysroleService.role(current,role);
		model.addAttribute("pi", pi);
		return "sys/role/list";
    }
    @RequestMapping(value="/sysrole/add", method = RequestMethod.GET)
    public String forwardadd(){
    	return "sys/role/add";
    }
    @RequestMapping(value="/sysrole/add", method = RequestMethod.POST)
    public String add(Sysrole sysrole){
       int rtn = sysroleService.add(sysrole);   
       if(rtn>0){
    	   return "redirect:/role/list";
       }else{
           return "redirect:/sysrole/add";
       }
    }
    @RequestMapping(value="/sysrole/toedit", method = RequestMethod.GET)
    public String toedit(@RequestParam("roleid") int roleid,Model model) {
		Sysrole role = new Sysrole();
		role.setRoleid(roleid);
		role = sysroleService.detail(role);
		if (role != null) {
			model.addAttribute("item", role);
			return "sys/role/edit";
		} else {
			   model.addAttribute("msg","出错了，请联系管理员");
		       return "error";
       }
    }
    @RequestMapping(value="/sysrole/edit" ,method=RequestMethod.POST)
	private String edit(Sysrole sysrole,Model model){
		
			Integer rtn = sysroleService.edit(sysrole);
			if (rtn > 0) {
				return "redirect:/role/list";
			} else {
				 model.addAttribute("msg","修改失败");
			     return "redirect：/sysrole/toedit";
			}
     }
    @RequestMapping(value="/sysrole/findall" ,method=RequestMethod.POST)
    private void list(Sysrole sysrole,Model model,HttpServletResponse response){
    	List<Sysrole> list = sysroleService.rolelist();
    	String json = JSON.toJSONString(list);
    	try {
			response.getWriter().println(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
