package cn.edu.nuc.carloan.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Bank;
import cn.edu.nuc.carloan.services.interfaces.BankService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月8日 下午5:35:49 
 *@ version:1.0
 *@ 类说明:银行控制层
 */
@Controller
@RequestMapping("/bank")
public class BankController {
  @Autowired
  private BankService bankService;
  @RequestMapping(value="/list",method=RequestMethod.POST)
  private void list(HttpServletResponse response){
	  
	List<Bank> list = bankService.selectAll();
	System.out.println(list+"--------");
  	String json = JSON.toJSONString(list);
  	try {
			response.getWriter().println(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }
  
  @RequestMapping(value="/add",method=RequestMethod.GET)
  private String forwardaddBank(){
	  return "company/addbank";
  }
  @RequestMapping(value="/add",method=RequestMethod.POST)
	public String addBank(Bank bank, @RequestParam("Img") MultipartFile Img,
			HttpServletRequest request) throws IOException {
			//获取文件 存储位置
			String realPath = request.getSession().getServletContext()
					.getRealPath("/assets/img/bank");
			File pathFile = new File(realPath);
			
			if (!pathFile.exists()) {
				//文件夹不存 创建文件
				pathFile.mkdirs();
			}
			String ext =FilenameUtils.getExtension(Img.getOriginalFilename());
			
			String filename = UUID.randomUUID()+"."+ext;
				
			FileUtils.copyInputStreamToFile(Img.getInputStream(), 
						new File(realPath, filename));

			bank.setBankImg(filename);
			int rtn = bankService.add(bank);
		    if(rtn>0){
		    	return "redirect:/bank/banklist";
		    }else{
		    	request.setAttribute("msg", "增加银行失败");
		    	return "company/addbank";
		    	}
	}
  /**
   * 银行列表
   * @param model
   * @param current
   * @return
   */
  @RequestMapping(value="/banklist",method=RequestMethod.GET)
  private String banklist(Model model,@RequestParam(name ="current", defaultValue = "1") int current){
	  PageInfo pi =  bankService.bankPage(current);
	  model.addAttribute("pi",pi);
	  return "company/banklist";
  }
  /**
   * 根据id查询信息并跳转到修改页面
   * @param bankId
   * @param model
   * @return
   */
  @RequestMapping(value="/detail",method=RequestMethod.GET)
  private String detail(@RequestParam("bankId") int bankId,Model model){
	 Bank bank = bankService.detail(bankId);
	 model.addAttribute("bank",bank);
	 return "company/editbank";
  }
  /**
   * 修改页面
   * @param bank
   * @return
   * @throws IOException 
   */
  @RequestMapping(value="/edit",method=RequestMethod.POST)
  private String edit(Bank bank, @RequestParam("Img") MultipartFile Img,HttpServletRequest request) throws IOException{
		//获取文件 存储位置
		String realPath = request.getSession().getServletContext()
				.getRealPath("/assets/img/bank");
		File pathFile = new File(realPath);
		
		if (!pathFile.exists()) {
			//文件夹不存 创建文件
			pathFile.mkdirs();
		}
		String ext =FilenameUtils.getExtension(Img.getOriginalFilename());
		
		String filename = UUID.randomUUID()+"."+ext;
			
		FileUtils.copyInputStreamToFile(Img.getInputStream(), 
					new File(realPath, filename));

		bank.setBankImg(filename);
	   int rtn = bankService.updateBank(bank);
	   if(rtn>0){
		return "redirect:/bank/banklist";
		}else{
			request.setAttribute("msg", "修改失败");
		    return "company/editbank";
		 }
  }
  
  /**
   * 删除页面
   * @param bankId
   * @return
   */
  @RequestMapping(value="/delete",method=RequestMethod.GET)
  private String delete(@RequestParam("bankId") int bankId){
	 int rtn = bankService.deleteById(bankId);
	 if(rtn>0){
		 return "redirect:/bank/banklist";
		 }else{
			 return "redirect:/bank/banklist";
		 }
  }
}
