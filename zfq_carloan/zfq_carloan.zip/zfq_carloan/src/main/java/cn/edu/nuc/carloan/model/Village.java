package cn.edu.nuc.carloan.model;
/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:03:37 
 *@ version:1.0
 *@ 类说明:
 */
public class Village {
  private Integer vid;
  private String vname;
  private Integer cityId;
public Integer getVid() {
	return vid;
}
public void setVid(Integer vid) {
	this.vid = vid;
}
public String getVname() {
	return vname;
}
public void setVname(String vname) {
	this.vname = vname;
}
public Integer getCityId() {
	return cityId;
}
public void setCityId(Integer cityId) {
	this.cityId = cityId;
}
@Override
public String toString() {
	return "Village [vid=" + vid + ", vname=" + vname + ", cityId=" + cityId + "]";
}
}
