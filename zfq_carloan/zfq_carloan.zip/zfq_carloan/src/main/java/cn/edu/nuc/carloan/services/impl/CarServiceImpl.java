package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.CarMapper;
import cn.edu.nuc.carloan.model.Car;
import cn.edu.nuc.carloan.services.interfaces.CarService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月6日 下午9:16:15 
 *@ version:1.0
 *@ 类说明:
 */
@Service
public class CarServiceImpl implements CarService {

	@Autowired
	private CarMapper carMapper;
	
	@Override
	public int addcar(Car car) {
		// TODO Auto-generated method stub
		int rtn = 0;
		if(car!=null){
		   rtn =carMapper.insertSelective(car);	
		}
		return rtn;
	}

	@Override
	public List<Car> selectAll() {
		// TODO Auto-generated method stub
		List<Car> list = carMapper.selectAll();
	    if(list!=null){
	    	return list;
	    }
		return null;
	}

}
