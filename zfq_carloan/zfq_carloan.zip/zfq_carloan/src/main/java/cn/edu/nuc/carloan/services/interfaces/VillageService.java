package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.model.Village;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:06:17 
 *@ version:1.0
 *@ 类说明:
 */
public interface VillageService {
  List<Village> villagelist(Integer cityId);
}
