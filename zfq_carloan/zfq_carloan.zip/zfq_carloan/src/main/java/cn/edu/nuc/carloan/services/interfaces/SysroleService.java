/**
 * 
 */
package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysrole;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午2:25:26 
 *@ version:1.0
 *@ 类说明：系统角色业务逻辑层接口
 */
public interface SysroleService {
	
	/**
	 * 角色列表
	 * @return list
	 */
	List<Sysrole> rolelist();
	/**
	 * 分页显示角色列表
	 * @param current
	 * @param role
	 * @return 分页
	 */
	PageInfo role( int current,Sysrole role);
	/**
	 * 角色信息
	 * @param role
	 * @return 角色对象
	 */
	Sysrole detail(Sysrole role);
	
	/**
	 * 增加角色
	 * @param role
	 * @return
	 */
	Integer add(Sysrole role);
	/**
	 * 编辑角色
	 * @param sysrole
	 * @return
	 */
	Integer edit(Sysrole sysrole);
	/**
	 * 根据角色id删除角色
	 * @param id
	 * @return
	 */
	Integer delete(Integer id);
	/**
	 * 根据角色id查询
	 * @param roleid
	 * @return
	 */
	Sysrole selectByroleid(int roleid);

}
