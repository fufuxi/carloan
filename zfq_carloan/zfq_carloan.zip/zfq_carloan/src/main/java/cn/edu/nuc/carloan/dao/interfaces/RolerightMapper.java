package cn.edu.nuc.carloan.dao.interfaces;

import cn.edu.nuc.carloan.model.Roleright;

public interface RolerightMapper {
    int deleteByPrimaryKey(Integer rrid);

    int insert(Roleright record);

    int insertSelective(Roleright record);

    Roleright selectByPrimaryKey(Integer rrid);

    int updateByPrimaryKeySelective(Roleright record);

    int updateByPrimaryKey(Roleright record);

	/**
	 * @param roleid
	 */
	int deleteByroleid(int roleid);
}