package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Loan;

public interface LoanMapper {
    int deleteByPrimaryKey(Integer loanId);

    int insertSelective(Loan record);

    Loan selectByPrimaryKey(Integer loanId);

	int count();

	List<Loan> findAll(@Param("start")int start, @Param("offset")int offset,@Param("custName") String custName);

	int updateByPrimaryKey(Loan loan);

}