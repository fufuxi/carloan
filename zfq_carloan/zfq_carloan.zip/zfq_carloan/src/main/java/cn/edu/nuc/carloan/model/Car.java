package cn.edu.nuc.carloan.model;
/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月6日 下午9:12:45 
 *@ version:1.0
 *@ 类说明:
 */
public class Car {
  private Integer carId;
  
  private String carBrand;
  
  private String carType;

public Integer getCarId() {
	return carId;
}

public void setCarId(Integer carId) {
	this.carId = carId;
}

public String getCarBrand() {
	return carBrand;
}

public void setCarBrand(String carBrand) {
	this.carBrand = carBrand;
}

public String getCarType() {
	return carType;
}

public void setCarType(String carType) {
	this.carType = carType;
}

@Override
public String toString() {
	return "Car [carId=" + carId + ", carBrand=" + carBrand + ", carType=" + carType + "]";
}
  
}
