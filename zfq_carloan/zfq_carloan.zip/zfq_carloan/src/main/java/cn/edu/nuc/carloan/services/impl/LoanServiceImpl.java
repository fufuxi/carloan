package cn.edu.nuc.carloan.services.impl;

import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import cn.edu.nuc.carloan.dao.interfaces.CityMapper;
import cn.edu.nuc.carloan.dao.interfaces.CustomerMapper;
import cn.edu.nuc.carloan.dao.interfaces.LoanMapper;
import cn.edu.nuc.carloan.dao.interfaces.VillageMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Loan;
import cn.edu.nuc.carloan.services.interfaces.LoanService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月3日 下午3:50:26 
 *@ version:1.0
 *@ 类说明:贷款业务业务逻辑层实现类
 */
@Service
public class LoanServiceImpl implements LoanService {

	@Autowired
	private LoanMapper loanMapper;
	@Autowired
	private CustomerMapper customerMapper;
	@Autowired
	private CityMapper cityMapper;
	@Autowired
	private VillageMapper villageMapper;
	private TransactionTemplate transactionTemplate;
	
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	@Override
	public PageInfo loanlist(int current, String custName) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		int count = loanMapper.count();      //总记录数
		pi.setCount(count);
		List<Loan> list = loanMapper.findAll(pi.getStart(), pi.getOffset(),custName);
		for(Loan loan : list){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			sdf.format(loan.getLcheckCustDate());
			
		}
		pi.setList(list);
		return pi;
	}
	
	@Override
	public PageInfo loanlist(int current){
		// TODO Auto-generated method stub
		return loanlist(current, null);
	}

	@Override
	public int addloan(final Loan loan) {
		// TODO Auto-generated method stub
	     int result = (int) transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				// TODO Auto-generated method stub
				customerMapper.insert(loan.getCustomer());
			    loanMapper.insertSelective(loan);
			}
		});
	     return result;
	}

	@Override
	public Loan detail(int loanId) {
		// TODO Auto-generated method stub
		Loan loan = loanMapper.selectByPrimaryKey(loanId);
		
		return loan;
	}

	@Override
	public int update(Loan loan) {
		// TODO Auto-generated method stub
		return loanMapper.updateByPrimaryKey(loan);
	}
	@Override
	public String method(Loan loan){
	String a = loan.getCustomer().getCustAdress();
	String[] ad = a.split("-");
	Integer cityid = null ,villageid = null ;
	for(int i = 0 ;i<ad.length;i++){
		 if(i==0){
			 cityid = Integer.parseInt(ad[i]);
		 }else{
			 villageid =Integer.parseInt(ad[i]);
		 }
	  }
	String city = cityMapper.selectById(cityid);
	String village = villageMapper.selectById(villageid);
	  return city+village;
	}

	
}
