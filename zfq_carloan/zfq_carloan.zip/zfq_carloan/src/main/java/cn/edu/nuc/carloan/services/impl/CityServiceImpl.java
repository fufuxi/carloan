package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.CityMapper;
import cn.edu.nuc.carloan.model.City;
import cn.edu.nuc.carloan.services.interfaces.CityService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:07:31 
 *@ version:1.0
 *@ 类说明:
 */
@Service
public class CityServiceImpl implements CityService {
	@Autowired
    private CityMapper cityMapper;
	@Override
	public List<City> citylist() {
		// TODO Auto-generated method stub
		return cityMapper.selectAll();
	}

}
