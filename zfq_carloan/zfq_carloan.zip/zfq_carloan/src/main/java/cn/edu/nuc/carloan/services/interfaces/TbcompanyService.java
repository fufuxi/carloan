package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Tbcompany;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月9日 下午5:49:08 
 *@ version:1.0
 *@ 类说明:投保公司业务逻辑层接口
 */

public interface TbcompanyService {
  
	/**
	 * 增加
	 * @param tbcompany
	 * @return
	 */
  int add(Tbcompany tbcompany);
  
   /**
    * 删除
    * @param tbId
    * @return
    */
  int delete(Integer tbId);
  
  /**
   * 根据id查询
   * @param tbId
   * @return
   */
  Tbcompany detail(Integer tbId);
  
  /**
   * 修改
   * @param tbcompany
   * @return
   */
  int update(Tbcompany tbcompany);
  
  /**
   * 查询所有
   * @return
   */
  List<Tbcompany> selectAll();
  
  /**
   * 分页查询所有
   * @param current
   * @return
   */
  PageInfo pageSelectAll(int current);
}
