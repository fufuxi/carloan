package cn.edu.nuc.carloan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSON;

import cn.edu.nuc.carloan.model.Village;
import cn.edu.nuc.carloan.services.interfaces.VillageService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:17:17 
 *@ version:1.0
 *@ 类说明:乡镇控制层
 */
@Controller
public class VillageController {
 @Autowired
 private VillageService villageService;
 
 @RequestMapping(value="/village/list")
 private void villagelist( @RequestParam("cityId") Integer cityId,HttpServletResponse response ) {
	 List<Village> list = villageService.villagelist(cityId);
	 String json = JSON.toJSONString(list);
	 try {
		response.getWriter().println(json);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
}
