package cn.edu.nuc.carloan.services.interfaces;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Loan;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月3日 下午3:41:20 
 *@ version:1.0
 *@ 类说明:贷款业务业务逻辑层接口
 */
public interface LoanService {
	
	/**
	 * 增加贷款
	 * @param loan
	 * @param user登记人
	 * @return
	 */
	int addloan(Loan loan);
	   
	   
	/**
	 * 分页显示
	 * @return
	 */
	PageInfo loanlist(int current);


	Loan detail(int loanId);


	int update(Loan loan);
	
	String method(Loan loan);


	PageInfo loanlist(int current, String custName);
}
