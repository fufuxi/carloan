package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Sysfunction;

public interface SysfunctionMapper {
	
	List<Sysfunction> selectAll();
	
	List<Sysfunction> selectByUser(Integer roleid);
	
    int deleteByPrimaryKey(Integer funid);

    int insert(Sysfunction record);

    int insertSelective(Sysfunction record);

    Sysfunction selectByPrimaryKey(Integer funid);

    int updateByPrimaryKeySelective(Sysfunction record);

    int updateByPrimaryKey(Sysfunction record);

	/**总记录数
	 * @return int类型
	 */
	int count();

	/** 分页查询
	 * @param start
	 * @param offset
	 * @return
	 */
	List<Sysfunction> findAll(@Param("start")int start,  @Param("offset")int offset ,@Param("funname") String funname);
	 /**
	  * 查询权限
	  * @param roleid
	  * @return
	  */
	List<Sysfunction> selectByroleid(@Param("roleid") int roleid );
}