package cn.edu.nuc.carloan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.fastjson.JSON;

import cn.edu.nuc.carloan.model.Car;
import cn.edu.nuc.carloan.services.interfaces.CarService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月6日 下午9:34:56 
 *@ version:1.0
 *@ 类说明:
 */
@Controller
public class CarController {
	@Autowired
	private CarService carService;
	 @RequestMapping(value="/car/list" ,method=RequestMethod.POST)
	    private void list(Car car,HttpServletResponse response){
	    	List<Car> list = carService.selectAll();
	    	String json = JSON.toJSONString(list);
	    	try {
				response.getWriter().println(json);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
}
