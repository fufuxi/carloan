package cn.edu.nuc.carloan.dao.interfaces;

import cn.edu.nuc.carloan.model.Insurance;

public interface InsuranceMapper {
    int deleteByPrimaryKey(Integer insureId);

    int insert(Insurance record);

    int insertSelective(Insurance record);

    Insurance selectByPrimaryKey(Integer insureId);

    int updateByPrimaryKeySelective(Insurance record);

    int updateByPrimaryKey(Insurance record);
}