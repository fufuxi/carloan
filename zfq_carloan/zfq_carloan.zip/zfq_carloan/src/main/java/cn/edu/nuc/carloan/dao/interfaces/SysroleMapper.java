package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Sysrole;

public interface SysroleMapper {
    int deleteByPrimaryKey(Integer roleid);

    int insert(Sysrole record);

    int insertSelective(Sysrole record);

    Sysrole selectByPrimaryKey(Integer roleid);

    int updateByPrimaryKeySelective(Sysrole record);

    int updateByPrimaryKey(Sysrole record);

	/**
	 * @return 总记录数
	 */
	int count();

	/** 分页查询
	 * @param start
	 * @param offset
	 * @return
	 */
	List<Sysrole> findAll(@Param("start")int start, @Param("offset")int offset,@Param("rolename") String rolename);

	/**
	 * @return
	 */
	List<Sysrole> rolelist();
}