package cn.edu.nuc.carloan.services.interfaces;

import cn.edu.nuc.carloan.model.Roleright;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午7:57:15 
 *@ version:1.0
 *@ 类说明：权限业务逻辑层接口
 */
public interface RolerightService {

	/**根据角色id删除权限
	 * @param roleid
	 * @return 
	 */
	int deleteByroleid(int roleid);

	/**
	 * 增加权限
	 * @param roleright
	 * @return
	 */
	int insert(Roleright roleright);
	
}
