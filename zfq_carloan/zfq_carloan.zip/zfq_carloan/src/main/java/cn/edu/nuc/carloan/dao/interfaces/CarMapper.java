package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.model.Car;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月6日 下午9:16:56 
 *@ version:1.0
 *@ 类说明:
 */
public interface CarMapper {
	
	int insertSelective(Car record);
	
	List<Car> selectAll();
}
