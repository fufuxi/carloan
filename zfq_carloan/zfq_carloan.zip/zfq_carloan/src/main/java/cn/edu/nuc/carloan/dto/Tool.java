package cn.edu.nuc.carloan.dto;
/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午4:32:02 
 *@ version:1.0
 *@ 类说明：工具类
 */
public class Tool {
   private PageInfo pageInfo;
   private String name;
	public PageInfo getPageInfo() {
		return pageInfo;
	}
	public void setPageInfo(PageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	}
