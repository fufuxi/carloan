package cn.edu.nuc.carloan.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.CustomerMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Customer;
import cn.edu.nuc.carloan.services.interfaces.CustomerService;
/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月2日 下午3:39:25 
 *@ version:1.0
 *@ 类说明:客户信息业务逻辑层实现类
 */
@Service
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerMapper customerMapper;
	@Override
	public PageInfo customer(int current, Customer customer) {
		// TODO Auto-generated method stub
	    PageInfo pi = new PageInfo(current);
	    int count = customerMapper.count();
	    pi.setCount(count);
	    List<Customer> list = customerMapper.findAll(pi.getStart(), pi.getOffset(),customer.getCustName());
		pi.setList(list);
		return pi;
	}

	@Override
	public Customer detail(int custId) {
		// TODO Auto-generated method stub
		return customerMapper.selectByPrimaryKey(custId);
	}

	@Override
	public Integer edit(Customer cust) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer add(Customer cust) {
		// TODO Auto-generated method stub
		return customerMapper.insertSelective(cust);
	}

	@Override
	public Customer selectByIdcard(String custIdcard) {
		// TODO Auto-generated method stub
		return customerMapper.selectByIdcard(custIdcard);
	}
	 
	public List<String> getData(String keyword) {
		// TODO Auto-generated method stub
		List<String> list = new ArrayList<>();
		List<String> datas = serachAllName();
		for(String data:datas){
			if(data.contains(keyword)){
			list.add(data);
		  }
		}
		return list;
	}

	@Override
	public List<String> serachAllName() {
		// TODO Auto-generated method stub
		List<String> list = customerMapper.serachname();
		return list;
	}

	@Override
	public String checkIdcard(Customer cust) {
		// TODO Auto-generated method stub
		 Customer c = customerMapper.selectByIdcard(cust.getCustIdcard());
		String rtn = "";
		if(c!=null){
			rtn = "Y";
		}else {
			rtn = "N";
		}
		return rtn;
	}
   

}
