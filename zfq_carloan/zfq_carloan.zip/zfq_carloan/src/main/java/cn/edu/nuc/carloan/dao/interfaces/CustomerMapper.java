package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Customer;

/**
 * 
 * @author 张富强
 *  持久层
 */
public interface CustomerMapper {
    int deleteByPrimaryKey(Integer custId);

    int insert(Customer record);

    int insertSelective(Customer record);

    Customer selectByPrimaryKey(Integer custId);

    int updateByPrimaryKeySelective(Customer record);

    int updateByPrimaryKey(Customer record);

	List<Customer> findAll(@Param("start")int start, @Param("offset")int offset, @Param("custName")String custName);

	int count();

	Customer selectByIdcard(@Param("custIdcard")String custIdcard);

	List<String> serachname();
}