/**
 * 
 */
package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysuser;

/**
 * @ author 张富强
 * @ Email 18435186714@163.com 
 * @ time: 2016年10月31日 下午3:12:25 
 * @ version:1.0 
 * @ 类说明:系统功能业务逻辑层接口
 */

public interface SysfunctionService {

	List<Sysfunction> initpage(Sysuser user);
	
	/**
	 * 分页显示功能列表
	 * @param aid
	 * @param current
	 * @return
	 */
	PageInfo function( int current,Sysfunction fun);

	/**功能详细信息
	 * @param fun
	 * @return
	 */
	Sysfunction detail(Sysfunction fun);

	/**编辑功能
	 * @param sysfunction
	 * @return
	 */
	Integer edit(Sysfunction sysfunction);

	/** 增加功能
	 * @param sysfunction
	 * @return
	 */
	Integer add(Sysfunction sysfunction);
	
	/**
	 * 根据角色id查询权限
	 * @param roleid
	 * @return
	 */
	List<Sysfunction> right(int roleid);

}
