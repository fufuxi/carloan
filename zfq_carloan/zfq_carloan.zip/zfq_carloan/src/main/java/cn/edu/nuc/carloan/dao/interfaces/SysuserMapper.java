package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysuser;

public interface SysuserMapper {
    int deleteByPrimaryKey(Integer userid);

    int insert(Sysuser record);

    int insertSelective(Sysuser record);

    Sysuser selectByPrimaryKey(Integer userid);

    int updateByPrimaryKeySelective(Sysuser record);

    int updateByPrimaryKey(Sysuser record);

	/**登录
	 * @param username
	 * @return
	 */
	Sysuser findByUsername(String username);

	/**总记录数
	 * @return
	 */
	int count();

	/**分页显示
	 * @param start
	 * @param offset
	 * @return
	 */
	List<Sysfunction> findAll(@Param("start")int start, @Param("offset")int offset,@Param("username") String username);

	/**查询所有用户名
	 * @return
	 */
	List<String> serachname();
}