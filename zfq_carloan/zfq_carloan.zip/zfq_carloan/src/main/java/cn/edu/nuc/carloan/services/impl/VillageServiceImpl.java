package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.VillageMapper;
import cn.edu.nuc.carloan.model.Village;
import cn.edu.nuc.carloan.services.interfaces.VillageService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:08:11 
 *@ version:1.0
 *@ 类说明:
 */
@Service
public class VillageServiceImpl implements VillageService {
    @Autowired
    private VillageMapper villageMapper;
	@Override
	public List<Village> villagelist(Integer cityId) {
		// TODO Auto-generated method stub
		return villageMapper.selectAllByCityId(cityId);
	}

}
