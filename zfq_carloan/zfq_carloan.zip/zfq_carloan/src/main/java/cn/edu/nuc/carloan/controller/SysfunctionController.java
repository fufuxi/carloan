/**
 * 
 */
package cn.edu.nuc.carloan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysuser;
import cn.edu.nuc.carloan.services.interfaces.SysfunctionService;

/**
 * @ author 张富强
 * @ Email 18435186714@163.com 
 * @ time: 2016年10月31日 下午3:09:50
 * @ version:1.0
 * @ 类说明：系统功能控制层
 */
@Controller
public class SysfunctionController {

	@Autowired
	private SysfunctionService sysfunctionService;

	@RequestMapping(value = "/c/{uid}/home", method = RequestMethod.GET)
	public String index(@PathVariable("uid") int aid, HttpSession session, Model model) {
		Sysuser user = (Sysuser) session.getAttribute("user");
		List<Sysfunction> list = sysfunctionService.initpage(user);
		model.addAttribute("list", list);
		return "index";
	}

	@RequestMapping(value = "/function/list")
	private String funlist(HttpServletRequest request, @RequestParam(name ="current", defaultValue = "1") int current,
			Model model) {
		String sname = request.getParameter("sname");
		Sysfunction fun = new Sysfunction();
		if (sname != null && !sname.equals("")) {
			fun.setFunname(sname);
		}
		PageInfo pi = sysfunctionService.function(current,fun);
		model.addAttribute("pi", pi);
		return "sys/function/list";
	}
	@RequestMapping(value="/function/add",method=RequestMethod.GET)
	private String forwardadd(@RequestParam("pid") int pid,@RequestParam("pname")String pname) {
		return "sys/function/add";
	}
	@RequestMapping(value="/function/add",method=RequestMethod.POST)
	private String add(Sysfunction sysfunction,Model model) {
		Integer rtn = sysfunctionService.add(sysfunction);
		if(rtn>0){
			return "redirect:/function/list";
		} else {
			 model.addAttribute("msg","增加失败");
		     return "redirect：/function/add";
	     }
	}
	@RequestMapping(value="/function/toedit",method=RequestMethod.GET)
	private String toedit(@RequestParam("id") int id,Model model) {
		Sysfunction fun = new Sysfunction();
		fun.setFunid(id);
		fun = sysfunctionService.detail(fun);
		if (fun != null) {
			model.addAttribute("item", fun);
			return "sys/function/edit";
		} else {
			   model.addAttribute("msg","出错了，请联系管理员");
		       return "error";
       }
    } 
		@RequestMapping(value="/function/edit" ,method=RequestMethod.POST)
		private String edit(Sysfunction sysfunction,Model model){
			
				Integer rtn = sysfunctionService.edit(sysfunction);
				if (rtn > 0) {
					return "redirect:/function/list";
				} else {
					 model.addAttribute("msg","修改失败");
				     return "redirect：/function/toedit";
				}
	}
}
