package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Bank;

public interface BankMapper {
    int deleteByPrimaryKey(Integer bankId);

    int insert(Bank record);

    int insertSelective(Bank bank);

    Bank selectByPrimaryKey(Integer bankId);

    int updateByPrimaryKeySelective(Bank record);

    int updateByPrimaryKey(Bank record);

	List<Bank> findAll();

	int count();

	List<Bank> PagefindAll(@Param("start")int start, @Param("offset")int offset);
}