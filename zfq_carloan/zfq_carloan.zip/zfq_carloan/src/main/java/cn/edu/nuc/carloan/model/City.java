package cn.edu.nuc.carloan.model;
/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:02:24 
 *@ version:1.0
 *@ 类说明:
 */
public class City {
  private Integer cityId;
  private String cityName;
public Integer getCityId() {
	return cityId;
}
public void setCityId(Integer cityId) {
	this.cityId = cityId;
}
public String getCityName() {
	return cityName;
}
public void setCityName(String cityName) {
	this.cityName = cityName;
}
@Override
public String toString() {
	return "City [cityId=" + cityId + ", cityName=" + cityName + "]";
}

}
