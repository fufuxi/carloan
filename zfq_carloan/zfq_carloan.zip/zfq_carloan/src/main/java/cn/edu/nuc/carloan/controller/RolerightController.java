package cn.edu.nuc.carloan.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.edu.nuc.carloan.model.Roleright;
import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysrole;
import cn.edu.nuc.carloan.services.interfaces.RolerightService;
import cn.edu.nuc.carloan.services.interfaces.SysfunctionService;
import cn.edu.nuc.carloan.services.interfaces.SysroleService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午7:55:58 
 *@ version:1.0
 *@ 类说明：权限控制层
 */
@Controller
public class RolerightController {
	@Autowired
	private SysroleService sysroleService;
	@Autowired
	private RolerightService rolerightService;
	@Autowired
	private SysfunctionService sysfunctionService;
	/**
	 * 初始化权限
	 * @param roleid
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/right/initright",method=RequestMethod.GET)
    public String initright(@RequestParam("roleid") int roleid,Model model){
    	Sysrole role = sysroleService.selectByroleid(roleid);
    	List<Sysfunction> list = sysfunctionService.right(roleid);
    	model.addAttribute("list", list);
    	model.addAttribute("role",role);
    	return "sys/role/right";
    }
	/**
	 * 保存权限
	 * @param request
	 * @param response
	 * @param roleid
	 * @return
	 */
	@RequestMapping(value="/right/saveright",method=RequestMethod.POST)
    public String saveright(HttpServletRequest request,
			HttpServletResponse response,@RequestParam("roleid") int roleid){
		String[] funids = request.getParameterValues("ckrr");
		rolerightService.deleteByroleid(roleid);
		Roleright roleright = new Roleright();
		roleright.setRoleid(roleid);
        for(int i=0;i<funids.length;i++){
    	   roleright.setFunid(Integer.parseInt(funids[i]));
    	   rolerightService.insert(roleright);
		}
		return "redirect:/role/list";
	}
}
