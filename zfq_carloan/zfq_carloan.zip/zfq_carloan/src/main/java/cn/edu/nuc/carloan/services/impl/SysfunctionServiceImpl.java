/**
 * 
 */
package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.SysfunctionMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysuser;
import cn.edu.nuc.carloan.services.interfaces.SysfunctionService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年10月31日 下午3:37:23 
 *@ version:1.0
 *@ 类说明：系统功能业务逻辑层实现类
 */
@Service
public class SysfunctionServiceImpl implements SysfunctionService {

	@Autowired 
	SysfunctionMapper sysfunctionMapper;

	@Override
	public List<Sysfunction> initpage(Sysuser user) {
		// TODO Auto-generated method stub
		List<Sysfunction> list = null;
		if(user.getSysrole().getRoleid() == -1){
			list = sysfunctionMapper.selectAll();
		}else{
			list = sysfunctionMapper.selectByUser(user.getSysrole().getRoleid() );
		}
		return list;
	}

	
	@Override
	public PageInfo function(int current,Sysfunction fun) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		int count = sysfunctionMapper.count();      //总记录数
		pi.setCount(count);
		List<Sysfunction> list = sysfunctionMapper.findAll(pi.getStart(), pi.getOffset(),fun.getFunname());
		pi.setList(list);
		
		return pi;
	}


	@Override
	public Sysfunction detail(Sysfunction fun) {
		// TODO Auto-generated method stub
		return sysfunctionMapper.selectByPrimaryKey(fun.getFunid());
	}


	@Override
	public Integer edit(Sysfunction sysfunction) {
		// TODO Auto-generated method stub
		return sysfunctionMapper.updateByPrimaryKeySelective(sysfunction);
	}

	@Override
	public Integer add(Sysfunction sysfunction) {
		// TODO Auto-generated method stub
		return sysfunctionMapper.insertSelective(sysfunction);
	}


	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysfunctionService#initright(int)
	 */
	@Override
	public List<Sysfunction> right(int roleid) {
		// TODO Auto-generated method stub
		return sysfunctionMapper.selectByroleid(roleid);
	}

}
