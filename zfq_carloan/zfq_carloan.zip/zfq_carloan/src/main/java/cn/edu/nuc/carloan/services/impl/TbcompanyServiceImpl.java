package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.TbcompanyMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Tbcompany;
import cn.edu.nuc.carloan.services.interfaces.TbcompanyService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月9日 下午5:51:09 
 *@ version:1.0
 *@ 类说明:投保公司业务逻辑层实现类
 */
@Service
public class TbcompanyServiceImpl implements TbcompanyService {
  
	@Autowired
	private TbcompanyMapper tbcompanyMapper;

	@Override
	public int add(Tbcompany tbcompany) {
		// TODO Auto-generated method stub
		return tbcompanyMapper.insertSelective(tbcompany);
	}

	@Override
	public int delete(Integer tbId) {
		// TODO Auto-generated method stub
		return tbcompanyMapper.deleteByPrimaryKey(tbId);
	}

	@Override
	public Tbcompany detail(Integer tbId) {
		// TODO Auto-generated method stub
		return tbcompanyMapper.selectByPrimaryKey(tbId);
	}

	@Override
	public int update(Tbcompany tbcompany) {
		// TODO Auto-generated method stub
		return tbcompanyMapper.updateByPrimaryKeySelective(tbcompany);
	}

	@Override
	public List<Tbcompany> selectAll() {
		// TODO Auto-generated method stub
		return tbcompanyMapper.findAll();
	}

	@Override
	public PageInfo pageSelectAll(int current) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		
		int count = tbcompanyMapper.count();
		pi.setCount(count);
		List<Tbcompany> list = tbcompanyMapper.pageSelectAll(pi.getStart(), pi.getOffset());
		pi.setList(list);
		return pi;
	}
	
	
}
