package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.model.City;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月7日 上午10:08:49 
 *@ version:1.0
 *@ 类说明:
 */
public interface CityMapper {
  List<City> selectAll();

String selectById(Integer cityid);
}
