/**
 * 
 */
package cn.edu.nuc.carloan.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.SysuserMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.exception.LoginException;
import cn.edu.nuc.carloan.model.Sysfunction;
import cn.edu.nuc.carloan.model.Sysuser;
import cn.edu.nuc.carloan.services.interfaces.SysuserService;


/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年10月31日 下午2:45:20 
 *@ version:1.0
 *@ 类说明：sysuser业务逻辑层实现类
 */
@Service
public class SysuserServiceImpl implements SysuserService {
	private transient Logger log = LoggerFactory.getLogger(SysuserServiceImpl.class);
	@Autowired
	private SysuserMapper sysuserMapper;
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysuserService#login(java.lang.String, java.lang.String)
	 */
	@Override
	public Sysuser login(String username, String userpwd) {
		// TODO Auto-generated method stub
		log.debug("用户{}正在登陆，密码是{}", username,userpwd);
		Sysuser user = sysuserMapper.findByUsername(username);
		if(user == null || (!userpwd.equals(user.getUserpwd()))){
			log.error("{}登陆失败",username);
			throw new LoginException("用户名或密码错误");
		}
		return user;
		
	}
	@Override
	public PageInfo userlist(int current,Sysuser user) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		int count = sysuserMapper.count();      //总记录数
		pi.setCount(count);
		List<Sysfunction> list = sysuserMapper.findAll(pi.getStart(), pi.getOffset(),user.getUsername());
		pi.setList(list);
		return pi;
	}
	
	@Override
	public Sysuser detail(Sysuser user) {
		// TODO Auto-generated method stub
		return sysuserMapper.selectByPrimaryKey(user.getUserid());
	}
	
	@Override
	public Integer edit(Sysuser user) {
		// TODO Auto-generated method stub
		return sysuserMapper.updateByPrimaryKeySelective(user);
	}
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysuserService#add(cn.edu.nuc.carloan.model.Sysuser)
	 */
	@Override
	public Integer add(Sysuser sysuser) {
		// TODO Auto-generated method stub
		return sysuserMapper.insertSelective(sysuser);
	}
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysuserService#serachAllName()
	 */
	@Override
	public List<String> serachAllName() {
		// TODO Auto-generated method stub
		List<String> list = sysuserMapper.serachname();
		return list ;
	}
	@Override
	public  List<String> getData(String keyword){
		 List<String> list = new ArrayList<>();
		 List<String> datas = serachAllName();
		for(String data:datas){
			if(data.contains(keyword)){
			list.add(data);
		  }
		}
		return list;
	 }
	@Override
	public int delete(int userid) {
		// TODO Auto-generated method stub
		return sysuserMapper.deleteByPrimaryKey(userid);
	}
}
