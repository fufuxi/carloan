package cn.edu.nuc.carloan.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Loan {
    private Integer loanId;

    private Customer customer;

    private Integer insureId;

    private Bank bank;

    private String carBrand;
    
    private String carType;
    
    private Double carPrice;
    
    private String carEngine;
    
    private String carGearbox;
    
    private Float carBoxsize;
    
    private String carRemark;
    
    private Double lsqmoney;

    private Integer lsqtime;
    
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date lsqdate;

    private Sysuser register;

    private Double lspmoney;
    
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date lspdate;
    
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date ldkdate;

    private String ldkcard;

    private Integer lfqnumber;

    private Integer lcheckCarUid;

    private String lcheckCarUname;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date lcheckCarDate;

    private Integer lcheckCarState;

    private Integer lcheckCustUid;

    private String lcheckCustUname;

   @DateTimeFormat(pattern="yyyy-MM-dd ")
    private Date lcheckCustDate;

    private Integer lcheckCustState;

    private Integer lcheckInsureUid;

    private String lcheckInsureUname;
    
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date lcheckInsureDate;

    private Integer lcheckInsureState;

    private Integer lcheckBankUid;

    private String lcheckBankUname;

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date lcheckBankDate;

    private Integer lcheckBankState;
    
    private Integer lstate;
    
    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	

    public Integer getInsureId() {
        return insureId;
    }

    public void setInsureId(Integer insureId) {
        this.insureId = insureId;
    }

  
    public String getCarBrand() {
		return carBrand;
	}

	public void setCarBrand(String carBrand) {
		this.carBrand = carBrand;
	}

	public String getCarType() {
		return carType;
	}

	public void setCarType(String carType) {
		this.carType = carType;
	}

	public Double getCarPrice() {
		return carPrice;
	}

	public void setCarPrice(Double carPrice) {
		this.carPrice = carPrice;
	}

	public String getCarEngine() {
		return carEngine;
	}

	public void setCarEngine(String carEngine) {
		this.carEngine = carEngine;
	}

	public String getCarGearbox() {
		return carGearbox;
	}

	public void setCarGearbox(String carGearbox) {
		this.carGearbox = carGearbox;
	}

	public Float getCarBoxsize() {
		return carBoxsize;
	}

	public void setCarBoxsize(Float carBoxsize) {
		this.carBoxsize = carBoxsize;
	}

	public String getCarRemark() {
		return carRemark;
	}

	public void setCarRemark(String carRemark) {
		this.carRemark = carRemark;
	}

	public Double getLsqmoney() {
        return lsqmoney;
    }

    public void setLsqmoey(Double lsqmoney) {
        this.lsqmoney = lsqmoney;
    }

    public Integer getLsqtime() {
        return lsqtime;
    }

    public void setLsqtime(Integer lsqtime) {
        this.lsqtime = lsqtime;
    }

    public Date getLsqdate() {
        return lsqdate;
    }

    public void setLsqdate(Date lsqdate) {
        this.lsqdate = lsqdate;
    }

    public Double getLspmoney() {
        return lspmoney;
    }

    public void setLspmoney(Double lspmoney) {
        this.lspmoney = lspmoney;
    }

    public Date getLspdate() {
        return lspdate;
    }

    public void setLspdate(Date lspdate) {
        this.lspdate = lspdate;
    }

    public Date getLdkdate() {
        return ldkdate;
    }

    public void setLdkdate(Date ldkdate) {
        this.ldkdate = ldkdate;
    }

    public String getLdkcard() {
        return ldkcard;
    }

    public void setLdkcard(String ldkcard) {
        this.ldkcard = ldkcard == null ? null : ldkcard.trim();
    }

    public Integer getLfqnumber() {
        return lfqnumber;
    }

    public void setLfqnumber(Integer lfqnumber) {
        this.lfqnumber = lfqnumber;
    }

    public Integer getLcheckCarUid() {
        return lcheckCarUid;
    }

    public void setLcheckCarUid(Integer lcheckCarUid) {
        this.lcheckCarUid = lcheckCarUid;
    }

    public String getLcheckCarUname() {
        return lcheckCarUname;
    }

    public void setLcheckCarUname(String lcheckCarUname) {
        this.lcheckCarUname = lcheckCarUname == null ? null : lcheckCarUname.trim();
    }

    public Date getLcheckCarDate() {
        return lcheckCarDate;
    }

    public void setLcheckCarDate(Date lcheckCarDate) {
        this.lcheckCarDate = lcheckCarDate;
    }

    public Integer getLcheckCarState() {
        return lcheckCarState;
    }

    public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public void setLsqmoney(Double lsqmoney) {
		this.lsqmoney = lsqmoney;
	}

	public void setLcheckCarState(Integer lcheckCarState) {
        this.lcheckCarState = lcheckCarState;
    }

    public Integer getLcheckCustUid() {
        return lcheckCustUid;
    }

    public void setLcheckCustUid(Integer lcheckCustUid) {
        this.lcheckCustUid = lcheckCustUid;
    }

    public String getLcheckCustUname() {
        return lcheckCustUname;
    }

    public void setLcheckCustUname(String lcheckCustUname) {
        this.lcheckCustUname = lcheckCustUname == null ? null : lcheckCustUname.trim();
    }

    public Date getLcheckCustDate() {
        return lcheckCustDate;
    }

    public void setLcheckCustDate(Date lcheckCustDate) {
        this.lcheckCustDate = lcheckCustDate;
    }

    public Integer getLcheckCustState() {
        return lcheckCustState;
    }

    public void setLcheckCustState(Integer lcheckCustState) {
        this.lcheckCustState = lcheckCustState;
    }

    public Integer getLcheckInsureUid() {
        return lcheckInsureUid;
    }

    public void setLcheckInsureUid(Integer lcheckInsureUid) {
        this.lcheckInsureUid = lcheckInsureUid;
    }

    public String getLcheckInsureUname() {
        return lcheckInsureUname;
    }

    public void setLcheckInsureUname(String lcheckInsureUname) {
        this.lcheckInsureUname = lcheckInsureUname == null ? null : lcheckInsureUname.trim();
    }

    public Date getLcheckInsureDate() {
        return lcheckInsureDate;
    }

    public void setLcheckInsureDate(Date lcheckInsureDate) {
        this.lcheckInsureDate = lcheckInsureDate;
    }

    public Integer getLcheckInsureState() {
        return lcheckInsureState;
    }

    public void setLcheckInsureState(Integer lcheckInsureState) {
        this.lcheckInsureState = lcheckInsureState;
    }

    public Integer getLcheckBankUid() {
        return lcheckBankUid;
    }

    public void setLcheckBankUid(Integer lcheckBankUid) {
        this.lcheckBankUid = lcheckBankUid;
    }

    public String getLcheckBankUname() {
        return lcheckBankUname;
    }

    public void setLcheckBankUname(String lcheckBankUname) {
        this.lcheckBankUname = lcheckBankUname == null ? null : lcheckBankUname.trim();
    }

    public Date getLcheckBankDate() {
        return lcheckBankDate;
    }

    public void setLcheckBankDate(Date lcheckBankDate) {
        this.lcheckBankDate = lcheckBankDate;
    }

    public Integer getLcheckBankState() {
        return lcheckBankState;
    }

    public void setLcheckBankState(Integer lcheckBankState) {
        this.lcheckBankState = lcheckBankState;
    }

	public Sysuser getRegister() {
		return register;
	}

	public void setRegister(Sysuser register) {
		this.register = register;
	}

	public Integer getLstate() {
		return lstate;
	}

	public void setLstate(Integer lstate) {
		this.lstate = lstate;
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customer=" + customer + ", insureId=" + insureId + ", bank=" + bank
				+ ", carBrand=" + carBrand + ", carType=" + carType + ", carPrice=" + carPrice + ", carEngine="
				+ carEngine + ", carGearbox=" + carGearbox + ", carBoxsize=" + carBoxsize + ", carRemark=" + carRemark
				+ ", lsqmoney=" + lsqmoney + ", lsqtime=" + lsqtime + ", lsqdate=" + lsqdate + ", register=" + register
				+ ", lspmoney=" + lspmoney + ", lspdate=" + lspdate + ", ldkdate=" + ldkdate + ", ldkcard=" + ldkcard
				+ ", lfqnumber=" + lfqnumber + ", lcheckCarUid=" + lcheckCarUid + ", lcheckCarUname=" + lcheckCarUname
				+ ", lcheckCarDate=" + lcheckCarDate + ", lcheckCarState=" + lcheckCarState + ", lcheckCustUid="
				+ lcheckCustUid + ", lcheckCustUname=" + lcheckCustUname + ", lcheckCustDate=" + lcheckCustDate
				+ ", lcheckCustState=" + lcheckCustState + ", lcheckInsureUid=" + lcheckInsureUid
				+ ", lcheckInsureUname=" + lcheckInsureUname + ", lcheckInsureDate=" + lcheckInsureDate
				+ ", lcheckInsureState=" + lcheckInsureState + ", lcheckBankUid=" + lcheckBankUid + ", lcheckBankUname="
				+ lcheckBankUname + ", lcheckBankDate=" + lcheckBankDate + ", lcheckBankState=" + lcheckBankState
				+ ", lstate=" + lstate + "]";
	}

	
}