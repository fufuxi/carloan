package cn.edu.nuc.carloan.controller;



import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Customer;
import cn.edu.nuc.carloan.services.interfaces.CustomerService;
import net.sf.json.JSONArray;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月2日 下午3:44:52 
 *@ version:1.0
 *@ 类说明:客户信息控制层
 */
@Controller
public class CustomerController {
	@Autowired
	private CustomerService customerService;
	@RequestMapping(value="/sysuser/checkIdcard",method=RequestMethod.POST)
	private void CheckIdcard(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		Customer cust = new Customer();
		cust.setCustIdcard(request.getParameter("Idcard"));
		String rtn = customerService.checkIdcard(cust);
	    try {
			response.getWriter().print(rtn);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@RequestMapping(value = "/customer/list")
	private String customerlist(HttpServletRequest request, @RequestParam(name ="current", defaultValue = "1") int current,
			Model model) {
		String cname = request.getParameter("custname");
		Customer cust = new Customer();
		if (cname != null && !cname.equals("")) {
			cust.setCustName(cname);;
		}
		PageInfo pi = customerService.customer(current, cust);
		model.addAttribute("pi", pi);
		return "customer/list";
	}
	@RequestMapping(value = "/customer/detail",method = RequestMethod.GET)
	private String detail(@RequestParam("custId") int custId,Model model){
		Customer cust = customerService.detail(custId);
	    model.addAttribute("cust",cust);
		return "customer/detail";
	}
	/**
	 * 查询所有名字
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value="/customer/serach" ,method=RequestMethod.GET)
	public void serach (HttpServletRequest request,HttpServletResponse response) throws Exception{
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String keyword = request.getParameter("keyword");
		List<String> listdata =  customerService.getData(keyword);
		response.getWriter().write(JSONArray.fromObject(listdata).toString());
	}
	
}
