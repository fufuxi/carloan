package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.BankMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Bank;
import cn.edu.nuc.carloan.services.interfaces.BankService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月8日 下午5:41:37 
 *@ version:1.0
 *@ 类说明:银行业务逻辑层实现类
 */
@Service
public class BankServiceImpl implements BankService{

	@Autowired
	private BankMapper bankMapper;
	
	@Override
	public List<Bank> selectAll() {
		// TODO Auto-generated method stub
		return bankMapper.findAll();
	}

	@Override
	public int add(Bank bank) {
		// TODO Auto-generated method stub
		return bankMapper.insertSelective(bank);
	}

	@Override
	public PageInfo bankPage(int current) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		int count = bankMapper.count();      //总记录数
		pi.setCount(count);
		List<Bank> list = bankMapper.PagefindAll(pi.getStart(), pi.getOffset());
		pi.setList(list);
		return pi;
	}

	@Override
	public int deleteById(int bankId) {
		// TODO Auto-generated method stub
		return bankMapper.deleteByPrimaryKey(bankId);
	}

	@Override
	public Bank detail(int bankId) {
		// TODO Auto-generated method stub
		return bankMapper.selectByPrimaryKey(bankId);
	}

	@Override
	public int updateBank(Bank bank) {
		// TODO Auto-generated method stub
		return bankMapper.updateByPrimaryKeySelective(bank);
	}

}
