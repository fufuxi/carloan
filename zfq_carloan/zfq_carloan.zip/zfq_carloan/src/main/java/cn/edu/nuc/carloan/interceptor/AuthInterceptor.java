/**
 * 
 */
package cn.edu.nuc.carloan.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import cn.edu.nuc.carloan.model.Sysuser;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年10月31日 下午4:26:27 
 *@ version:1.0
 *@ 类说明:拦截器
 */
public class AuthInterceptor implements HandlerInterceptor {

	@Override
	public void afterCompletion(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, Exception arg3)
			throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public void postHandle(HttpServletRequest arg0, HttpServletResponse arg1, Object arg2, ModelAndView arg3)
			throws Exception {
		// TODO Auto-generated method stub
        
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object arg2) throws Exception {
		// TODO Auto-generated method stub
	    HttpSession session = request.getSession();
	    Sysuser user = (Sysuser) session.getAttribute("user");
	      if(user!=null){
	    	return true;
	      }else{
	    	response.sendRedirect("/Sysuser/login");
	      return false;
	}
  }
}
