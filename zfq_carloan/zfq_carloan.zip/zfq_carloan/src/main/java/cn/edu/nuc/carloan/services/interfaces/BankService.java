package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Bank;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月8日 下午5:40:21 
 *@ version:1.0
 *@ 类说明:银行业务逻辑层接口
 */
public interface BankService {
    /**
     * 查询所有
     * @return
     */
	List<Bank> selectAll();
    /**
     * 增加
     * @param bank
     * @return
     */
	int add(Bank bank);

	/**
	 * 分页显示
	 * @param current
	 * @return
	 */
	PageInfo bankPage(int current);

	/**
	 * 根据id删除
	 * @param bankId
	 * @return
	 */
	int deleteById(int bankId);
	/**
	 * 根据id查询信息
	 * @param bankId
	 * @return
	 */
	Bank detail(int bankId);
	/**
	 * 修改
	 * @param bank
	 * @return
	 */
	int updateBank(Bank bank);
  
}
