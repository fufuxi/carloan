package cn.edu.nuc.carloan.model;

public class Customer {
    private Integer custId;

    private String custName;

    private String custPwd;

    private Integer custSex;

    private String custPhone;

    private String custIdcard;

    private String custAdress;

    private Integer custMarryState;

    private String custDriveState;

    private Double custMoney;

    private Integer custDebtState;

    private Double custDebtMoney;

    public Integer getCustId() {
        return custId;
    }

    public void setCustId(Integer custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName == null ? null : custName.trim();
    }

    public String getCustPwd() {
        return custPwd;
    }

    public void setCustPwd(String custPwd) {
        this.custPwd = custPwd == null ? null : custPwd.trim();
    }

    public Integer getCustSex() {
        return custSex;
    }

    public void setCustSex(Integer custSex) {
        this.custSex = custSex;
    }

    public String getCustPhone() {
        return custPhone;
    }

    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone == null ? null : custPhone.trim();
    }

    public String getCustIdcard() {
        return custIdcard;
    }

    public void setCustIdcard(String custIdcard) {
        this.custIdcard = custIdcard == null ? null : custIdcard.trim();
    }

    public String getCustAdress() {
        return custAdress;
    }

    public void setCustAdress(String custAdress) {
        this.custAdress = custAdress == null ? null : custAdress.trim();
    }

    public Integer getCustMarryState() {
        return custMarryState;
    }

    public void setCustMarryState(Integer custMarryState) {
        this.custMarryState = custMarryState;
    }

    public String getCustDriveState() {
        return custDriveState;
    }

    public void setCustDriveState(String custDriveState) {
        this.custDriveState = custDriveState == null ? null : custDriveState.trim();
    }

    public Double getCustMoney() {
        return custMoney;
    }

    public void setCustMoney(Double custMoney) {
        this.custMoney = custMoney;
    }

    public Integer getCustDebtState() {
        return custDebtState;
    }

    public void setCustDebtState(Integer custDebtState) {
        this.custDebtState = custDebtState;
    }

    public Double getCustDebtMoney() {
        return custDebtMoney;
    }

    public void setCustDebtMoney(Double custDebtMoney) {
        this.custDebtMoney = custDebtMoney;
    }

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", custPwd=" + custPwd + ", custSex=" + custSex
				+ ", custPhone=" + custPhone + ", custIdcard=" + custIdcard + ", custAdress=" + custAdress
				+ ", custMarryState=" + custMarryState + ", custDriveState=" + custDriveState + ", custMoney="
				+ custMoney + ", custDebtState=" + custDebtState + ", custDebtMoney=" + custDebtMoney + "]";
	}
    
}