package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Customer;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月2日 下午3:35:05 
 *@ version:1.0
 *@ 类说明:客户信息业务逻辑层接口
 */
public interface CustomerService {
	
	PageInfo customer( int current,Customer customer);
	/**
	 * 详细信息
	 * @param cust
	 * @return
	 */
	Customer detail(int custId);

	/**
	 * 编辑客户信息
	 * @param cust
	 * @return
	 */
	Integer edit(Customer cust);

	/**
	 * 增加客户信息
	 * @param cust
	 * @return
	 */
	Integer add(Customer cust);
	/**
	 * 
	 * @param custIdcard
	 * @return 
	 */
	Customer selectByIdcard(String custIdcard);
	/**
	 * 查询姓名
	 * @param keyword
	 * @return
	 */
	List<String> getData(String keyword);
	
	List<String> serachAllName();
	
	String checkIdcard(Customer cust);
}
