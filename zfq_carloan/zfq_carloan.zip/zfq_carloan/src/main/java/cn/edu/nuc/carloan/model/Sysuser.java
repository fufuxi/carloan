package cn.edu.nuc.carloan.model;

public class Sysuser {
    private Integer userid;

    private Sysrole sysrole;

    private String username;

    private String userpwd;

    private String usertruename;

    private Integer userstate;

    public Integer getUserid() {
        return userid;
    }

    public void setUserid(Integer userid) {
        this.userid = userid;
    }

    public Sysrole getSysrole() {
		return sysrole;
	}

	public void setSysrole(Sysrole sysrole) {
		this.sysrole = sysrole;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username == null ? null : username.trim();
    }

    public String getUserpwd() {
        return userpwd;
    }

    public void setUserpwd(String userpwd) {
        this.userpwd = userpwd == null ? null : userpwd.trim();
    }

    public String getUsertruename() {
        return usertruename;
    }

    public void setUsertruename(String usertruename) {
        this.usertruename = usertruename == null ? null : usertruename.trim();
    }

    public Integer getUserstate() {
        return userstate;
    }

    public void setUserstate(Integer userstate) {
        this.userstate = userstate;
    }

	@Override
	public String toString() {
		return "Sysuser [userid=" + userid + ", sysrole=" + sysrole + ", username=" + username + ", userpwd=" + userpwd
				+ ", usertruename=" + usertruename + ", userstate=" + userstate + "]";
	}
    
}