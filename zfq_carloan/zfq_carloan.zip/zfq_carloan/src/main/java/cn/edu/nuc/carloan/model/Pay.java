package cn.edu.nuc.carloan.model;

import java.util.Date;

public class Pay {
    private Integer payId;

    private Integer loanId;

    private Date payDate;

    private Float payMoney;

    private Integer payNum;

    private Float payBalance;

    private Float payInterest;

    public Integer getPayId() {
        return payId;
    }

    public void setPayId(Integer payId) {
        this.payId = payId;
    }

    public Integer getLoanId() {
        return loanId;
    }

    public void setLoanId(Integer loanId) {
        this.loanId = loanId;
    }

    public Date getPayDate() {
        return payDate;
    }

    public void setPayDate(Date payDate) {
        this.payDate = payDate;
    }

    public Float getPayMoney() {
        return payMoney;
    }

    public void setPayMoney(Float payMoney) {
        this.payMoney = payMoney;
    }

    public Integer getPayNum() {
        return payNum;
    }

    public void setPayNum(Integer payNum) {
        this.payNum = payNum;
    }

    public Float getPayBalance() {
        return payBalance;
    }

    public void setPayBalance(Float payBalance) {
        this.payBalance = payBalance;
    }

    public Float getPayInterest() {
        return payInterest;
    }

    public void setPayInterest(Float payInterest) {
        this.payInterest = payInterest;
    }
}