package cn.edu.nuc.carloan.model;

public class Tbcompany {
    private Integer tbId;

    private String tbName;
    
    private String tbPhone;
    
    private String tbImg;
    
    private String tbUrl;

	public Integer getTbId() {
		return tbId;
	}

	public void setTbId(Integer tbId) {
		this.tbId = tbId;
	}

	public String getTbName() {
		return tbName;
	}

	public void setTbName(String tbName) {
		this.tbName = tbName;
	}

	public String getTbUrl() {
		return tbUrl;
	}

	public void setTbUrl(String tbUrl) {
		this.tbUrl = tbUrl;
	}

	public String getTbPhone() {
		return tbPhone;
	}

	public void setTbPhone(String tbPhone) {
		this.tbPhone = tbPhone;
	}

	public String getTbImg() {
		return tbImg;
	}

	public void setTbImg(String tbImg) {
		this.tbImg = tbImg;
	}

	@Override
	public String toString() {
		return "Tbcompany [tbId=" + tbId + ", tbName=" + tbName + ", tbPhone=" + tbPhone + ", tbImg=" + tbImg
				+ ", tbUrl=" + tbUrl + "]";
	}
   
}