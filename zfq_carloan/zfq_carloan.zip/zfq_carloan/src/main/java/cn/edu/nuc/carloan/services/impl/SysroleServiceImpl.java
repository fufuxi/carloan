/**
 * 
 */
package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.SysroleMapper;
import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysrole;
import cn.edu.nuc.carloan.services.interfaces.SysroleService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午2:33:17 
 *@ version:1.0
 *@ 类说明：系统角色业务逻辑层实现类
 */
@Service
public class SysroleServiceImpl implements SysroleService {

	@Autowired
	private SysroleMapper sysroleMapper;
	
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#rolelist()
	 */
	@Override
	public List<Sysrole> rolelist() {
		// TODO Auto-generated method stub
		return sysroleMapper.rolelist();
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#role(int)
	 */
	@Override
	public PageInfo role(int current,Sysrole role) {
		// TODO Auto-generated method stub
		PageInfo pi = new PageInfo(current);
		int count = sysroleMapper.count();      //总记录数
		pi.setCount(count);
		List<Sysrole> list = sysroleMapper.findAll(pi.getStart(), pi.getOffset(),role.getRolename());
		pi.setList(list);
		return pi;
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#detail(cn.edu.nuc.carloan.model.Sysrole)
	 */
	@Override
	public Sysrole detail(Sysrole role) {
		// TODO Auto-generated method stub
		return sysroleMapper.selectByPrimaryKey(role.getRoleid());
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#add(cn.edu.nuc.carloan.model.Sysrole)
	 */
	@Override
	public Integer add(Sysrole role) {
		// TODO Auto-generated method stub
		return sysroleMapper.insertSelective(role);
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#edit(cn.edu.nuc.carloan.model.Sysrole)
	 */
	@Override
	public Integer edit(Sysrole sysrole) {
		// TODO Auto-generated method stub
		return sysroleMapper.updateByPrimaryKeySelective(sysrole);
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#delete(java.lang.Integer)
	 */
	@Override
	public Integer delete(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.SysroleService#selectByroleid(int)
	 */
	@Override
	public Sysrole selectByroleid(int roleid) {
		// TODO Auto-generated method stub
		return sysroleMapper.selectByPrimaryKey(roleid);
	}

}
