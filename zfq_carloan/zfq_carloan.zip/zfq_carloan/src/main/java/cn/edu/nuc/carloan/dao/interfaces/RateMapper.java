package cn.edu.nuc.carloan.dao.interfaces;

import cn.edu.nuc.carloan.model.Rate;

public interface RateMapper {
    int deleteByPrimaryKey(Integer rateid);

    int insert(Rate record);

    int insertSelective(Rate record);

    Rate selectByPrimaryKey(Integer rateid);

    int updateByPrimaryKeySelective(Rate record);

    int updateByPrimaryKey(Rate record);
}