package cn.edu.nuc.carloan.dto;

import java.util.List;


public class PageInfo {
	/**
	 * 当前页
	 */
	private int current = 1;
	/**
	 * 总记录数
	 */
	private int count;
	/**
	 * 页大小，初始每页5条记录
	 */
	private int offset = 5;
	/**
	 * 共几页
	 */
	private int total;
	/**
	 * 开始页
	 */
	private int start;
	/**
	 * 
	 */
	private List<?> list;
	
	public List<?> getList() {
		return list;
	}

	public void setList(List<?> list) {
		this.list = list;
	}

	public PageInfo(int current) {
		// TODO Auto-generated constructor stub
	 this.current = current;
	}

	public void setCount(int count) {
		// TODO Auto-generated method stub
		this.count = count;
        this.setTotal(
				this.count / this.offset 
					+ ((this.count % this.offset) > 0 ? 1 : 0)
					);
	}

	public int getStart() {
		// TODO Auto-generated method stub
		this.start = (this.current - 1) * this.offset;
		return start;
	}

	public int getOffset() {
		return offset;
	}

	public int getCurrent() {
		return current;
	}

	public void setCurrent(int current) {
		this.current = current;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getCount() {
		return count;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public void setOffset(int offset) {
		if( offset > 0 )
			this.offset = offset;
	}

	
	@Override
	public String toString() {
		return "PageInfo [current=" + current + ", count=" + count + ", offset=" + offset + ", total=" + total
				+ ", start=" + start + ", list=" + list + "]";
	}
}
