/**
 * 
 */
package cn.edu.nuc.carloan.services.interfaces;

import java.util.List;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysuser;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年10月31日 下午2:40:13 
 *@ version:1.0
 *@ 类说明:Sysuser业务逻辑层接口
 */

public interface SysuserService {

	/**
	 * 登录
	 * @param username
	 * @param userpwd
	 * @return Sysuser对象
	 */
	Sysuser login(String username,String userpwd);
	/**
	 * 分页用户列表
	 * @param current
	 * @param user
	 * @return
	 */
     PageInfo userlist(int current,Sysuser user);
	/**
	 * @param user
	 * @return
	 */
	Sysuser detail(Sysuser user);
	/**修改用户
	 * @param user
	 * @return
	 */
	Integer edit(Sysuser user);
	/**增加
	 * @param sysuser
	 * @return
	 */
	Integer add(Sysuser sysuser);
	/**
	 * 查询所有用户名
	 * @return
	 */
	List<String> serachAllName();
	
	List<String> getData(String keyword);
	
	/**
	 * 删除
	 * @param userid
	 * @return
	 */
	int delete(int userid);
}
