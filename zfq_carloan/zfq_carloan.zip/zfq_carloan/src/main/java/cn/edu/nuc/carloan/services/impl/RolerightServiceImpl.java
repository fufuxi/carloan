package cn.edu.nuc.carloan.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.edu.nuc.carloan.dao.interfaces.RolerightMapper;
import cn.edu.nuc.carloan.model.Roleright;
import cn.edu.nuc.carloan.services.interfaces.RolerightService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月1日 下午8:46:58 
 *@ version:1.0
 *@ 类说明：权限业务逻辑层实现类
 */
@Service
public class RolerightServiceImpl implements RolerightService {

	@Autowired
	private RolerightMapper rolerightMapper;
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.RolerightService#deleteByroleid(int)
	 */
	@Override
	public int deleteByroleid(int roleid) {
		// TODO Auto-generated method stub
		return rolerightMapper.deleteByroleid(roleid);
		
	}
	
	/* (non-Javadoc)
	 * @see cn.edu.nuc.carloan.services.interfaces.RolerightService#insert(int, java.lang.String)
	 */
	@Override
	public int insert(Roleright roleright) {
		// TODO Auto-generated method stub
		return rolerightMapper.insertSelective(roleright);
	}

}
