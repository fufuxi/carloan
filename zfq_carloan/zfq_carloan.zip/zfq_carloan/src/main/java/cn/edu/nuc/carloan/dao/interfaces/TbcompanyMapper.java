package cn.edu.nuc.carloan.dao.interfaces;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.edu.nuc.carloan.model.Tbcompany;

public interface TbcompanyMapper {
    int deleteByPrimaryKey(Integer tbId);

    int insert(Tbcompany record);

    int insertSelective(Tbcompany record);

    Tbcompany selectByPrimaryKey(Integer tbId);

    int updateByPrimaryKeySelective(Tbcompany record);

    int updateByPrimaryKey(Tbcompany record);
    
    List<Tbcompany> findAll();
    
    int count();
    
    List<Tbcompany> pageSelectAll(@Param("start") int start, @Param("offset") int offset);
}