package cn.edu.nuc.carloan.controller;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Loan;
import cn.edu.nuc.carloan.model.Sysuser;
import cn.edu.nuc.carloan.services.interfaces.LoanService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月3日 下午7:00:02 
 *@ version:1.0
 *@ 类说明:贷款控制层
 */
@Controller
@RequestMapping(value="/loan")
public class LoanController {
  
	@Autowired
	private LoanService loanService;
	/**
	 * 贷款登记
	 * @return
	 */
	@RequestMapping(value="/registry",method = RequestMethod.GET)
	private String registry(){
		return "/loan/registry";
	}
	@RequestMapping(value="/registry",method = RequestMethod.POST)
	private String addloan(Loan loan,HttpSession session){
		String address = loanService.method(loan);
		loan.getCustomer().setCustAdress(address);
		//System.out.println("地址："+loan.getCustomer().getCustAdress());   //方便测试
		Sysuser user = (Sysuser)session.getAttribute("user");
		loan.setLsqdate(new Date());
		loan.setRegister(user);
		int rtn = loanService.addloan(loan);
		if(rtn>0){
			return "redirect:/loan/list";
		}else{
			return "redirect:/loan/registry";
		}
	}
	
	@RequestMapping(value="/list")
	private String list(HttpServletRequest request , @RequestParam(name = "current", defaultValue = "1") int current,
			Model model){
		String custName = request.getParameter("custName");
	    PageInfo pi;
	    if(custName!= null && !custName.equals("")){
	    	 pi = loanService.loanlist(current,custName);
	    }else{
		   pi = loanService.loanlist(current);
		}
		model.addAttribute("pi", pi);
		return "loan/list";
	}
	@RequestMapping(value = "/detail",method = RequestMethod.GET)
	private String detail(@RequestParam("loanId") int loanId,Model model){
		Loan loan = loanService.detail(loanId);
		model.addAttribute("loan", loan);
		return "loan/detail";
	}
	@RequestMapping(value = "/review/customer/list",method = RequestMethod.GET)
	private String reviewcustlist(HttpServletRequest request, @RequestParam(name = "current", defaultValue = "1") int current,
			Model model){
	    PageInfo pi = loanService.loanlist(current);
	    model.addAttribute("pi", pi);
		return "loan/review/customer/custlist";
	 }
	@RequestMapping(value = "/review/customer/toedit",method = RequestMethod.GET)
	private String reviewcust(@RequestParam("loanid") int loanId,Model model){
		Loan loan = loanService.detail(loanId);
		model.addAttribute("loan", loan);
		return "loan/review/customer/edit";
	}
	@RequestMapping(value = "/review/customer/edit",method = RequestMethod.POST)
	private String reviewcust(Loan loan){
		loan.setLcheckCustDate(new Date());
		int rtn = loanService.update(loan);
		if(rtn>0){
		    return "redirect:/loan/review/customer/list";
		}else{
			return "";
		}
	}
	@RequestMapping(value = "/review/car/list",method = RequestMethod.GET)
	private String reviewcarlist(HttpServletRequest request, @RequestParam(name = "current", defaultValue = "1") int current,
			Model model){
	    PageInfo pi = loanService.loanlist(current);
	    model.addAttribute("pi", pi);
		return "loan/review/car/carlist";
	 }
	@RequestMapping(value = "/review/car/toedit",method = RequestMethod.GET)
	private String reviewcar(@RequestParam("loanid") int loanId,Model model){
		Loan loan = loanService.detail(loanId);
		model.addAttribute("loan", loan);
		return "loan/review/car/edit";
	}
		@RequestMapping(value = "/review/car/edit",method = RequestMethod.POST)
		private String reviewcar(Loan loan){
			loan.setLcheckCarDate(new Date());
			int rtn = loanService.update(loan);
			if(rtn>0){
			    return "redirect:/loan/review/car/list";
			}else{
				return "";
			}
		}
}
