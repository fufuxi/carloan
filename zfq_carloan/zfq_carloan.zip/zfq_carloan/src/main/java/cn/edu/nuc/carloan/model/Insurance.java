package cn.edu.nuc.carloan.model;

import java.util.Date;

public class Insurance {
    private Integer insureId;

    private Integer tbcompId;

    private Date insureStartTime;

    private Date insureEndTime;

    private Double insureMoney;

    private Double allmoney;

    public Integer getInsureId() {
        return insureId;
    }

    public void setInsureId(Integer insureId) {
        this.insureId = insureId;
    }

    public Integer getTbcompId() {
        return tbcompId;
    }

    public void setTbcompId(Integer tbcompId) {
        this.tbcompId = tbcompId;
    }

    public Date getInsureStartTime() {
        return insureStartTime;
    }

    public void setInsureStartTime(Date insureStartTime) {
        this.insureStartTime = insureStartTime;
    }

    public Date getInsureEndTime() {
        return insureEndTime;
    }

    public void setInsureEndTime(Date insureEndTime) {
        this.insureEndTime = insureEndTime;
    }

    public Double getInsureMoney() {
        return insureMoney;
    }

    public void setInsureMoney(Double insureMoney) {
        this.insureMoney = insureMoney;
    }

    public Double getAllmoney() {
        return allmoney;
    }

    public void setAllmoney(Double allmoney) {
        this.allmoney = allmoney;
    }
}