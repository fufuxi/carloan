package cn.edu.nuc.carloan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import cn.edu.nuc.carloan.model.Bank;
import cn.edu.nuc.carloan.model.Tbcompany;
import cn.edu.nuc.carloan.services.interfaces.BankService;
import cn.edu.nuc.carloan.services.interfaces.TbcompanyService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月9日 下午5:47:18 
 *@ version:1.0
 *@ 类说明:公司管理
 */
@Controller
public class CompanyController {
  @Autowired
  private BankService bankService;
  @Autowired 
  private TbcompanyService tbcompanyService;
  
  @RequestMapping(value="company/list",method=RequestMethod.GET)
  private String list(Model model){
	  List<Bank> banklist = bankService.selectAll();
	  List<Tbcompany> tbcompanylist = tbcompanyService.selectAll();
	  model.addAttribute("banklist",banklist);
	  model.addAttribute("tbcompanylist", tbcompanylist);
	  return "company/list";
  }
  
  
}
