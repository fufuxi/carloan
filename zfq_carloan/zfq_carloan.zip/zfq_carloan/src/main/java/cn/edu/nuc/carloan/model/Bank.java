package cn.edu.nuc.carloan.model;

public class Bank {
    private Integer bankId;

    private String bankName;

    private String bankSimpleName;

    private String bankAddress;

    private String bankPhone;

    
    private String bankImg;
    
    private String bankUrl;
    
    public Integer getBankId() {
        return bankId;
    }
    public void setBankId(Integer bankId) {
        this.bankId = bankId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName == null ? null : bankName.trim();
    }

    public String getBankSimpleName() {
        return bankSimpleName;
    }

    public void setBankSimpleName(String bankSimpleName) {
        this.bankSimpleName = bankSimpleName == null ? null : bankSimpleName.trim();
    }

    public String getBankAddress() {
        return bankAddress;
    }

    public void setBankAddress(String bankAddress) {
        this.bankAddress = bankAddress == null ? null : bankAddress.trim();
    }

    public String getBankPhone() {
        return bankPhone;
    }

    public void setBankPhone(String bankPhone) {
        this.bankPhone = bankPhone == null ? null : bankPhone.trim();
    }


	public String getBankImg() {
		return bankImg;
	}

	public void setBankImg(String bankImg) {
		this.bankImg = bankImg;
	}
	public String getBankUrl() {
		return bankUrl;
	}
	public void setBankUrl(String bankUrl) {
		this.bankUrl = bankUrl;
	}
	@Override
	public String toString() {
		return "Bank [bankId=" + bankId + ", bankName=" + bankName + ", bankSimpleName=" + bankSimpleName
				+ ", bankAddress=" + bankAddress + ", bankPhone=" + bankPhone + ", bankImg=" + bankImg + ", bankUrl="
				+ bankUrl + "]";
	}
    
}