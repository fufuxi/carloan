/**
 * 
 */
package cn.edu.nuc.carloan.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Sysuser;
import cn.edu.nuc.carloan.services.interfaces.SysuserService;
import net.sf.json.JSONArray;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年10月31日 下午2:36:48 
 *@ version:1.0
 *@ 类说明:系统用户控制层
 */

@Controller
public class SysuserController {
	@Autowired
	private SysuserService sysuserService;
	@RequestMapping(value="/logout",method=RequestMethod.GET)
	private String logout(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		return "redirect:/Sysuser/login";
	}
	/**
	 * 地址栏输入Sysuser/login 跳转到login.jsp
	 * @param sysuser
	 * @return login.jsp
	 */
	@RequestMapping(value="/Sysuser/login",method=RequestMethod.GET)
	public String forward(@ModelAttribute("sysuser") Sysuser sysuser){
		return "login";
	}
	/**
	 * login.jsp表单输入内容点击提交
	 * @param session
	 * @param user
	 * @return 成功跳转到首页，失败继续在login.jsp
	 */
	@RequestMapping(value="/Sysuser/login",method=RequestMethod.POST)
	public String login(HttpSession session,HttpServletRequest request,Sysuser user) {
		try {
			user = sysuserService.login(user.getUsername(), user.getUserpwd());
			session.setAttribute("user", user);
			return "redirect:/c/"+user.getUserid() + "/home";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			request.setAttribute("msg", "用户名或密码错误");
			e.printStackTrace();
		}
		return "login";
	}
	
	/**
	 * 跳转到修改密码页面
	 * @return
	 */
	@RequestMapping(value="/sysuser/editpwd",method=RequestMethod.GET)
	private String forwardeditpwd(){
		return "sys/user/updatepwd";
	}
	/**
	 * 修改密码
	 * @param request
	 * @param response
	 * @param session
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value="/sysuser/editpwd",method=RequestMethod.POST)
	private String editpwd(HttpServletRequest request,HttpServletResponse response,HttpSession session) throws IOException {
		String userpwd = request.getParameter("userpwd");
		Sysuser user = (Sysuser) session.getAttribute("user");
		user.setUserpwd(userpwd);
		int rtn = sysuserService.edit(user);
		if(rtn>0){
			session.removeAttribute("user");
		 	response.sendRedirect("/Sysuser/login");
		 	return null;
		}else{
			return "redirect:/sysuser/editpwd";
		}
		
	}
	/**
	 * 分页显示用户列表
	 * @param request
	 * @param current
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/sysuser/list")
	public String list(HttpServletRequest request, @RequestParam(name = "current", defaultValue = "1") int current,
			Model model)  {
		String username = request.getParameter("username");
		Sysuser user = new Sysuser();
		if (username != null && !username.equals("")) {
			user.setUsername(username);
		}
		PageInfo pi = sysuserService.userlist(current,user);
		model.addAttribute("pi", pi);
		return "sys/user/list";
	}
	/**
	 * 跳转到增加页面
	 * @return
	 */
	@RequestMapping(value="/sysuser/add",method=RequestMethod.GET)
	private String forwardadd() {
		return "sys/user/add";
	}
	/**
	 * 增加用户
	 * @param sysuser
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/sysuser/add",method=RequestMethod.POST)
	private String add(Sysuser sysuser,Model model) {
		Integer rtn = sysuserService.add(sysuser);
		if(rtn>0){
			return "redirect:/sysuser/list";
		} else {
			 model.addAttribute("msg","增加失败");
		     return "redirect：/sysuser/add";
	     }
	}
	/**
	 * 跳转到修改页面
	 * @param userid
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/sysuser/toedit",method=RequestMethod.GET)
	private String toedit(@RequestParam("userid") int userid,Model model) {
		Sysuser user = new Sysuser();
		user.setUserid(userid);
		user = sysuserService.detail(user);
		if (user != null) {
			model.addAttribute("item", user);
			return "sys/user/edit";
		} else {
			   model.addAttribute("msg","出错了，请联系管理员");
		       return "error";
       }
     } 
	/**
	 * 修改页面
	 * @param sysuser
	 * @param model
	 * @return
	 */
		@RequestMapping(value="/sysuser/edit" ,method=RequestMethod.POST)
		private String edit(Sysuser sysuser,Model model){
			
				Integer rtn = sysuserService.edit(sysuser);
				if (rtn > 0) {
					return "redirect:/sysuser/list";
				} else {
					 model.addAttribute("msg","修改失败");
				     return "redirect：/function/toedit";
				}
	     }
		/**
		 * 查询所有名字
		 * @param request
		 * @param response
		 * @throws Exception
		 */
		@RequestMapping(value="/user/serach" ,method=RequestMethod.GET)
		public void serach (HttpServletRequest request,HttpServletResponse response) throws Exception{
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			String keyword = request.getParameter("keyword");
			List<String> listdata =  sysuserService.getData(keyword);
			response.getWriter().write(JSONArray.fromObject(listdata).toString());
		}
		@RequestMapping(value="/sysuser/delete",method=RequestMethod.GET)
		private String delete(@RequestParam("userid") int userid) {
			
			int rtn  = sysuserService.delete(userid);
			if (rtn > 0) {
				return "redirect:/sysuser/list";
			} else {
				return "redirect:/sysuser/list";
	       }
	     } 		
}

