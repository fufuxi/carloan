package cn.edu.nuc.carloan.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;

import cn.edu.nuc.carloan.dto.PageInfo;
import cn.edu.nuc.carloan.model.Tbcompany;
import cn.edu.nuc.carloan.services.interfaces.TbcompanyService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月10日 下午9:46:44 
 *@ version:1.0
 *@ 类说明:投保公司控制层
 */
@Controller
@RequestMapping("/tbcompany")
public class TbcompanyController {
	@Autowired
	  private TbcompanyService tbcompanyService;
	  @RequestMapping(value="/list",method=RequestMethod.POST)
	  private void list(HttpServletResponse response){
		  
		List<Tbcompany> list = tbcompanyService.selectAll();

		String json = JSON.toJSONString(list);
	  	try {
				response.getWriter().println(json);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }
	  
	  @RequestMapping(value="/add",method=RequestMethod.GET)
	  private String forwardaddBank(){
		  return "company/addtbcompany";
	  }
	  @RequestMapping(value="/add",method=RequestMethod.POST)
		public String addBank(Tbcompany tbcompany, @RequestParam("Img") MultipartFile Img,
				HttpServletRequest request) throws IOException {
				//获取文件 存储位置
				String realPath = request.getSession().getServletContext()
						.getRealPath("/assets/img/tb");
				File pathFile = new File(realPath);
				
				if (!pathFile.exists()) {
					//文件夹不存 创建文件
					pathFile.mkdirs();
				}
				String ext =FilenameUtils.getExtension(Img.getOriginalFilename());
				
				String filename = UUID.randomUUID()+"."+ext;
					
				FileUtils.copyInputStreamToFile(Img.getInputStream(), 
							new File(realPath, filename));

				tbcompany.setTbImg(filename);
				int rtn = tbcompanyService.add(tbcompany);
			    if(rtn>0){
			    	return "redirect:/tbcompany/tbcomanylist";
			    }else{
			    	request.setAttribute("msg", "增加银行失败");
			    	return "company/addtbcompany";
			    	}
		}
	  /**
	   * 列表
	   * @param model
	   * @param current
	   * @return
	   */
	  @RequestMapping(value="/tbcomanylist",method=RequestMethod.GET)
	  private String banklist(Model model,@RequestParam(name ="current", defaultValue = "1") int current){
		  PageInfo pi =  tbcompanyService.pageSelectAll(current);
		  model.addAttribute("pi",pi);
		  return "company/tbcompanylist";
	  }
	  /**
	   * 根据id查询信息并跳转到修改页面
	   * @param tbId
	   * @param model
	   * @return
	   */
	  @RequestMapping(value="/detail",method=RequestMethod.GET)
	  private String detail(@RequestParam("tbId") int tbId,Model model){
		 Tbcompany tbcompany = tbcompanyService.detail(tbId);
		 model.addAttribute("tbcompany",tbcompany);
		 return "company/edittbcompany";
	  }
	  /**
	   * 修改页面
	   * @param tbcompany
	   * @param bookImg
	   * @param request
	   * @return
	   * @throws IOException
	   */
	  @RequestMapping(value="/edit",method=RequestMethod.POST)
	  private String edit(Tbcompany tbcompany, @RequestParam("Img") MultipartFile Img,HttpServletRequest request) throws IOException{
			//获取文件 存储位置
			String realPath = request.getSession().getServletContext()
					.getRealPath("/assets/img/tb");
			File pathFile = new File(realPath);
			
			if (!pathFile.exists()) {
				//文件夹不存 创建文件
				pathFile.mkdirs();
			}
			String ext =FilenameUtils.getExtension(Img.getOriginalFilename());
			
			String filename = UUID.randomUUID()+"."+ext;
				
			FileUtils.copyInputStreamToFile(Img.getInputStream(), 
						new File(realPath, filename));

			tbcompany.setTbImg(filename);
		   int rtn = tbcompanyService.update(tbcompany);
		   if(rtn>0){
			return "redirect:/tbcompany/tbcompanylist";
			}else{
				request.setAttribute("msg", "修改失败");
			    return "company/edittbcompany";
			 }
	  }
	  
	  /**
	   * 删除页面
	   * @param tbId
	   * @return
	   */
	  @RequestMapping(value="/delete",method=RequestMethod.GET)
	  private String delete(@RequestParam("tbId") int tbId){
		 int rtn = tbcompanyService.delete(tbId);
		 if(rtn>0){
			 return "redirect:/tbcompany/tbcompanylist";
			 }else{
				 return "redirect:/tbcompany/tbcompanylist";
			 }
	  }
}
