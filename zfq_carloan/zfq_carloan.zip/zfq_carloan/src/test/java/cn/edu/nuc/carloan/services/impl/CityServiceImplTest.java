package cn.edu.nuc.carloan.services.impl;


import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.model.City;
import cn.edu.nuc.carloan.services.interfaces.CityService;



public class CityServiceImplTest extends BaseTest {
   @Autowired
   private CityService cityService;
	

	@Test
	public void testSelectAll() {
		List<City> list = cityService.citylist();
	   System.out.println(list);
	  
	}

}
