package cn.edu.nuc.carloan.services.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.model.Car;
import cn.edu.nuc.carloan.services.interfaces.CarService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月4日 下午3:07:11 
 *@ version:1.0
 *@ 类说明:
 */

public class CarServiceImplTest extends BaseTest {
   @Autowired
   private CarService carService;
	@Test
	public void testCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public void testDetail() {
		fail("Not yet implemented");
	}

	@Test
	public void testEdit() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectByIdcard() {
		List<Car> list = carService.selectAll();
	   System.out.println(list);
	  
	}

}
