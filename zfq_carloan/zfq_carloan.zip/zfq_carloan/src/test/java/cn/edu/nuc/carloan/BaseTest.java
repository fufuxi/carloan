package cn.edu.nuc.carloan;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月4日 下午3:09:17 
 *@ version:1.0
 *@ 类说明:测试基本包
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:spring-context.xml"})
public class BaseTest {

}
