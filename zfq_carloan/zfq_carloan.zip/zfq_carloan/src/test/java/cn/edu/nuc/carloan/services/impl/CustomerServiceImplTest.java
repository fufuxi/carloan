package cn.edu.nuc.carloan.services.impl;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.dao.interfaces.LoanMapper;
import cn.edu.nuc.carloan.model.Loan;
import cn.edu.nuc.carloan.services.interfaces.CustomerService;
import cn.edu.nuc.carloan.services.interfaces.LoanService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月4日 下午3:07:11 
 *@ version:1.0
 *@ 类说明:
 */

public class CustomerServiceImplTest extends BaseTest {
   @Autowired
   private CustomerService customerService;
   @Autowired
   private LoanService loanService;
   @Autowired
   private LoanMapper LoanMapper;
	@Test
	public void testCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public void testDetail() {
		fail("Not yet implemented");
	}

	@Test
	public void testEdit() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	public void test(){
		Loan loan = new Loan();
		loan.setLcheckCustUid(1);
		loan.setLcheckCustUname("admin");
		loan.setLcheckCustState(1);
		loan.setLcheckCustDate(new Date());
		loan.setLoanId(7);
		int v = LoanMapper.updateByPrimaryKey(loan);
		System.out.println("---"+v);
	}

}
