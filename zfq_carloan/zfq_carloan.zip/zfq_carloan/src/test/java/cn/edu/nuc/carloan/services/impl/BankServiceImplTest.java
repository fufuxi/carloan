package cn.edu.nuc.carloan.services.impl;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.dao.interfaces.BankMapper;
import cn.edu.nuc.carloan.model.Bank;
import cn.edu.nuc.carloan.services.interfaces.BankService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月9日 上午8:57:19 
 *@ version:1.0
 *@ 类说明:
 */
public class BankServiceImplTest extends BaseTest {
  
	@Autowired
	private BankService bankService;
	@Autowired
	private BankMapper bankMapper;
	
	
	@Test
	public void test(){
		List<Bank> list = bankService.selectAll();
		System.out.println(list);
	}
	@Test
	public void tes1(){
		Bank b = bankMapper.selectByPrimaryKey(1);
		System.out.println(b);
	}
}
