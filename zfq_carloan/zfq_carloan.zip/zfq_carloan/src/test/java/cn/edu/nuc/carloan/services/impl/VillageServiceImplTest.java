package cn.edu.nuc.carloan.services.impl;


import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.model.Village;
import cn.edu.nuc.carloan.services.interfaces.VillageService;



public class VillageServiceImplTest extends BaseTest {
   @Autowired
   private VillageService villageService ;
	

	@Test
	public void testSelectAll() {
		List<Village> list = villageService.villagelist(1);
	   System.out.println(list);
	  
	}

}
