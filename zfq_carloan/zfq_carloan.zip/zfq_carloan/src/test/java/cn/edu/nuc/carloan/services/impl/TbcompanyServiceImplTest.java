package cn.edu.nuc.carloan.services.impl;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import cn.edu.nuc.carloan.BaseTest;
import cn.edu.nuc.carloan.dao.interfaces.TbcompanyMapper;
import cn.edu.nuc.carloan.model.Tbcompany;
import cn.edu.nuc.carloan.services.interfaces.TbcompanyService;

/**
 *@ author 张富强
 *@ Email 18435186714@163.com
 *@ time: 2016年11月4日 下午3:07:11 
 *@ version:1.0
 *@ 类说明:
 */

public class TbcompanyServiceImplTest extends BaseTest {
   @Autowired
   private TbcompanyService tbcompanyService;
   @Autowired
   private TbcompanyMapper tbcompanyMapper;
	@Test
	public void testCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public void testDetail() {
		fail("Not yet implemented");
	}

	@Test
	public void testEdit() {
		fail("Not yet implemented");
	}

	@Test
	public void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	public void testSelectAll() {
		List<Tbcompany> list = tbcompanyService.selectAll();
	   System.out.println(list);
	  
	}
	@Test
	public void testSelectAll2() {
		List<Tbcompany> list = tbcompanyMapper.findAll();
	   System.out.println(list);
	  
	}

}
